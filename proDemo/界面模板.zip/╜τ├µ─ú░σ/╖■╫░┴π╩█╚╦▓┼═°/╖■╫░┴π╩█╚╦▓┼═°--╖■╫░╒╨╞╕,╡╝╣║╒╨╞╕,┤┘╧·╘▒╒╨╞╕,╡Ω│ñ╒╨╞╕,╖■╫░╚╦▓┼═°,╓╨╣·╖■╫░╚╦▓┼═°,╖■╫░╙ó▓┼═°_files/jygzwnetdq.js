function $(str){ return document.getElementById(str);}
 function $$(str){ return document.getElementsByTagName(str);}
 var timer;
 function changeMenu(thisObj,num){
  if(thisObj.className=="over") return false;
  hids(thisObj);
  thisObj.className="over";
  $("c"+(num+1)).className="block";
  
  $("c"+(num+1)).onmouseover=function(){clearTimeout(timer);}
  $("c"+(num+1)).onmouseout=function(){timer=setTimeout(function(){hids(thisObj);},500)}
  thisObj.onmouseout=function(){timer=setTimeout(function(){hids(thisObj);},3000)}
  
 }
 function hids(thisObj){
  clearTimeout(timer);
  var tabObj=thisObj.parentNode.getAttribute("id");
  var obj_dt=$(tabObj).getElementsByTagName("dt");
  for(var i=0;i<obj_dt.length;i++){
   obj_dt[i].className="normal";
   $("c"+(i+1)).className="none";
  }
 }