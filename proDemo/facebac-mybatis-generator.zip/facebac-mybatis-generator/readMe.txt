﻿##########################################
#                                        #
#	mybatis 自动生成代码工具         #
#                                        #
##########################################

1：直接修改 generatorConfig.xml 文件
	jdbcConnection：mysql连接属性
	javaModelGenerator：实体类存放地方
	sqlMapGenerator：map xml文件存放地方
	javaClientGenerator：dao 文件存放地方

2：generatorConfig.xml 文件中不能有注释。

3：修改表名，类名
	tableName="count_usercdn_dk_day" domainObjectName="CountUsercdnDkDay"	

4：包不要先创建，会自动创建。
	建议每次使用之前把 src 目录下面清空

5：最后运行 run.bat 会在 src 下面生成相关的文件