package com.facebac.yun.service.business.api.impl;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.facebac.yun.common.Config;
import com.facebac.yun.common.ManageRedisKeyContants;
import com.facebac.yun.common.utils.Commonutils;
import com.facebac.yun.common.utils.Constants;
import com.facebac.yun.common.utils.ContextHolderUtils;
import com.facebac.yun.common.utils.HttpRequest;
import com.facebac.yun.common.utils.LogUtils;
import com.facebac.yun.common.utils.MD5Utils;
import com.facebac.yun.common.utils.ObjectConvert;
import com.facebac.yun.common.utils.Report;
import com.facebac.yun.common.utils.ThreadManagerUtil;
import com.facebac.yun.console.redis.RedisBDBService;
import com.facebac.yun.console.redis.RedisDB15_RID;
import com.facebac.yun.console.redis.RedisDBService;
import com.facebac.yun.model.api.ParamStream;
import com.facebac.yun.model.dto.RedisDB15Obj;
import com.facebac.yun.model.entity.live.LiveInfo;
import com.facebac.yun.model.entity.user.UserCallback;
import com.facebac.yun.model.entity.user.UserInfo;
import com.facebac.yun.model.entity.user.UserServerInfo;
import com.facebac.yun.model.entity.video.VideoInfo;
import com.facebac.yun.model.entity.video.VideoupInfo;
import com.facebac.yun.model.vo.CommonAuV;
import com.facebac.yun.service.business.api.ILiveStreamService;
import com.facebac.yun.service.data.live.ILiveInfoService;
import com.facebac.yun.service.data.user.IUserCallbackService;
import com.facebac.yun.service.data.user.IUserInfoService;
import com.facebac.yun.service.data.user.IUserServerInfoService;
import com.facebac.yun.service.data.video.IVideoInfoService;
import com.facebac.yun.service.data.video.IVideoupInfoService;
import com.sun.xml.internal.ws.api.policy.PolicyResolver.ServerContext;

import net.sf.json.JSONObject;

/**
 * @author  leihua
 * @date [2016年3月21日 上午9:10:42]
 * @version   1.0
 */
@Service("liveStreamServiceImpl")
public class LiveStreamServiceImpl implements ILiveStreamService,ManageRedisKeyContants {
	
	@Resource(name = "userInfoServiceImpl")
	private IUserInfoService userInfoServiceImpl;
	
	@Resource(name = "liveInfoServiceImpl")
	private ILiveInfoService liveInfoServiceImpl;
	
	@Resource(name = "videoInfoServiceImpl")
	private IVideoInfoService videoInfoServiceImpl;
	
	@Resource(name = "videoupInfoServiceImpl")
	private IVideoupInfoService videoupInfoServiceImpl;
	
	@Resource(name = "redisBDBService")
	private RedisBDBService redisBDBService;
	
	@Resource(name = "redisDB15_RID")
	private RedisDB15_RID redisDB15_RID;
	
	@Resource(name="userCallbackServiceImpl")
	private IUserCallbackService userCallbackServiceImpl;
	
	@Resource(name = "redisDBService")
	private RedisDBService redisDBService;
	
	@Resource(name = "userServerInfoServiceImpl")
	private IUserServerInfoService uSImpl ;
	
	@Autowired
	private Config configInfo;
	
	/*
	 * redis缓存用户
	 * @time 2018-1-20 16:50:27
	 * 时效 10s钟
	 * type 1 通过token查询 2通过uid查询 
	 * @property:缓存属性   id,userName,userStatus, userkey rid
	 * 若后期使用到对象较多属性 可以使用序列化SerializeUtil 全部存储到redis
	 */
	private UserInfo redisIOUser(String token,int type,ServletContext application){
		Map userMap = null;
		try {
			userMap = redisBDBService.HGETALL("SUSER:"+token);
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("redisB connection exception,method:redisIOUser");
			if(Commonutils.checkRep(Constants.Code_redisB_Con_Exc, 100, application)){
				ThreadManagerUtil.getInstance().execute(new Report("redisB connect exception", "liveStreamServiceImpl.redisIOUser", 3));
			}
		}
		UserInfo userInfo = new UserInfo();
		try {
			int limCountTmp = configInfo.getLimicount() > 0?configInfo.getLimicount() : 200;
			if (null != userMap ){
				userInfo.setId(null == userMap.get("id")?null:userMap.get("id").toString());
				userInfo.setUserName(null == userMap.get("userName")?null:userMap.get("userName").toString());
				String userStatus = (null == userMap.get("userStatus")?null:userMap.get("userStatus").toString());
				userInfo.setUserStatus(null == userStatus?0:Integer.decode(userStatus));
				userInfo.setUserKey(null == userMap.get("userkey")?null:userMap.get("userkey").toString());
				userInfo.setRid(null == userMap.get("rid")?null:userMap.get("rid").toString());
				userInfo.setLimitCount(null == userMap.get("limitCount")?limCountTmp:Long.parseLong(userMap.get("limitCount").toString()));
			}else{	//reides无数据，查询mysql
				try {
					if(type == 1){
						userInfo = userInfoServiceImpl.selectByRid(token);
					}else{
						userInfo = userInfoServiceImpl.selectByPrimaryKey(token);
					}
				} catch (Exception e) {
					// TODO: handle exception
					if(Commonutils.checkRep(Constants.Code_Sql_Con_Exc, 100, application)){
						ThreadManagerUtil.getInstance().execute(new Report("sql connect exception", "liveStreamServiceImpl.redisIOUser", 3));
					}
				}
				if (userInfo==null){
					return userInfo;
				}
				String limitKey = "USERLIMIT:"+MD5Utils.getMD5String(userInfo.getId());
				String limitCount = redisDBService.GET(limitKey);
				userInfo.setLimitCount(null == limitCount?Long.parseLong(String.valueOf(limCountTmp)):Long.parseLong(limitCount));
				/**
				 * user 入redis 4 用户库
				 */
				Map inUserMap = new HashMap();
				inUserMap.put("id", userInfo.getId());
				inUserMap.put("userName", userInfo.getUserName());
				inUserMap.put("userStatus", null == userInfo.getUserStatus()?"0":userInfo.getUserStatus().toString());
				inUserMap.put("userkey", null == userInfo.getUserKey()?"":userInfo.getUserKey());
				inUserMap.put("rid", userInfo.getRid());
				inUserMap.put("limitCount", null == limitCount?String.valueOf(limCountTmp):String.valueOf(limitCount));
				try {
					redisBDBService.HSET("SUSER:" + token, inUserMap,10); //入 redis库， 有效期20分钟
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("redis connection exception,method:redisIOUser");
				}
			}
			return userInfo;
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("catch redisIOUser error");
			return null;
		}
	}
	
	/*
	 * redis缓存用户服务信息
	 * @time 2018-11-22 
	 * 时效 20分钟 
	 * @property:缓存属性   id,userServerType,liveCdn
	 * 若后期使用到对象较多属性 可以使用序列化SerializeUtil 全部存储到redis
	 */
	private UserServerInfo redisUserServer(String uid,ServletContext application){
		Map userServerMap = new HashMap();
		try {
			userServerMap = redisBDBService.HGETALL("SUSERSERVER:"+uid);
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("redis connection exception,method:liveStreamServiceImpl.redisUserServer");
		}
		UserServerInfo usf = new UserServerInfo();
		try {
			if (null != userServerMap ){
				usf.setId(null == userServerMap.get("id")?null:userServerMap.get("id").toString());
				String userServerType = (null == userServerMap.get("userServerType")?null:userServerMap.get("userServerType").toString());
				usf.setUserServerType(null == userServerType?0:Integer.parseInt(userServerType));
				String liveCdn = (null == userServerMap.get("liveCdn")?null:userServerMap.get("liveCdn").toString());
				usf.setLiveCdn(null == liveCdn?1:Integer.parseInt(liveCdn));
			}else{	//reides无数据，查询mysql
				try {
					usf = uSImpl.selectByPrimaryKey(uid);
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("sql connection exception,method:liveStreamServiceImpl.redisUserServer");
				}
				if (usf == null){
					return null;
				}
				/**
				 * userserver 入redis 4 用户库
				 */
				Map inUserServerMap = new HashMap();
				inUserServerMap.put("id", usf.getId());
				inUserServerMap.put("userServerType", usf.getUserServerType().toString());
				inUserServerMap.put("liveCdn", usf.getLiveCdn().toString());
				try {
					redisBDBService.HSET("SUSERSERVER:" + uid, inUserServerMap,300); //入 redis库， 有效期20分钟
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("redis connection exception,method:liveStreamServiceImpl.redisUserServer");
				}
			}
			return usf;
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("catch redisIOUser error");
			return null;
		}
	}
	
	
	/*
	 * redis 缓存用户回调信息表
	 * @time 2018年1月22日14:09:57
	 * @property:缓存属性   id,userId,callbackUrl
	 * 时效 30分钟
	 */
	private UserCallback redisIOUserCallBack(String uid,ServletContext application){
		Map userCallMap = new HashMap();
		try {
			userCallMap = redisBDBService.HGETALL("SUSERCALL:"+uid);
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("redis connection exception,method:liveStreamServiceImpl.redisIOUserCallBack");
		}
		UserCallback userCallBack = new UserCallback();
		try {
			if (null != userCallMap ){
				userCallBack.setId(null == userCallMap.get("id")?null:userCallMap.get("id").toString());
				userCallBack.setUserId(null == userCallMap.get("userId")?null:userCallMap.get("userId").toString());
				userCallBack.setCallbackUrl(null == userCallMap.get("callbackUrl")?"":userCallMap.get("callbackUrl").toString());
				userCallBack.setLiveStart(null == userCallMap.get("live_start")?"":userCallMap.get("live_start").toString());
				userCallBack.setLiveEnd(null == userCallMap.get("live_end")?"":userCallMap.get("live_end").toString());
				userCallBack.setLiveAuth(null == userCallMap.get("live_auth")?"":userCallMap.get("live_auth").toString());
				userCallBack.setVideoAuth(null == userCallMap.get("video_auth")?"":userCallMap.get("video_auth").toString());
				userCallBack.setVideoupAuth(null == userCallMap.get("videoup_auth")?"":userCallMap.get("videoup_auth").toString());
				userCallBack.setUserCallback(null == userCallMap.get("userCallback")?"":userCallMap.get("userCallback").toString());
				userCallBack.setCallbackType(null == userCallMap.get("callbackType")?"":userCallMap.get("callbackType").toString());
			}else{	//reides无数据，查询mysql
				try {
					userCallBack = userCallbackServiceImpl.selectByIdCallback(uid);
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("sql connection exception,method:liveStreamServiceImpl.redisIOUserCallBack");
				}
				if (userCallBack==null){
					return userCallBack;
				}
				/**
				 * user 入redis 4 用户库
				 */
				Map inUserCallMap = new HashMap();
				inUserCallMap.put("id", userCallBack.getId());
				inUserCallMap.put("userId", userCallBack.getUserId());
				inUserCallMap.put("callbackUrl", null == userCallBack.getCallbackUrl()?"":userCallBack.getCallbackUrl());
				inUserCallMap.put("live_start", StringUtils.isBlank(userCallBack.getLiveStart())?"":userCallBack.getLiveStart());
				inUserCallMap.put("live_end", StringUtils.isBlank(userCallBack.getLiveEnd())?"":userCallBack.getLiveEnd());
				inUserCallMap.put("live_auth", StringUtils.isBlank(userCallBack.getLiveAuth())?"":userCallBack.getLiveAuth());
				inUserCallMap.put("video_auth", StringUtils.isBlank(userCallBack.getVideoAuth())?"":userCallBack.getVideoAuth());
				inUserCallMap.put("videoup_auth", StringUtils.isBlank(userCallBack.getVideoupAuth())?"":userCallBack.getVideoupAuth());
				inUserCallMap.put("userCallback", StringUtils.isBlank(userCallBack.getUserCallback())?"":userCallBack.getUserCallback());
				inUserCallMap.put("callbackType", StringUtils.isBlank(userCallBack.getCallbackType())?"":userCallBack.getCallbackType());
				//inUserCallMap.put("userCallback", StringUtils.isBlank(userCallBack.getUserCallback())?"":userCallBack.getUserCallback());
				try {
					redisBDBService.HSET("SUSERCALL:" + uid, inUserCallMap,20); //入 redis库， 有效期20分钟
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("redis connection exception,method:liveStreamServiceImpl.redisIOUserCallBack");
				}
			}
			return userCallBack;
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("catch redisIOUserCallMap error,uid:userCallbak");
			return userCallBack;
		}
	}
	
	/*
	 * redis缓存直播
	 * @time 2018-1-20 16:50:27
	 * 时效 10分钟 
	 * @property:缓存属性   id,rid,liveName, liveStatus liveSwitch onlineCount liveCoverUrl userId pushCode
	 * 若后期使用到对象较多属性 可以使用序列化SerializeUtil 全部存储到redis		
	 * ------------redisDBService 改换另一台服务器  redisBDBService
	 */
	private LiveInfo redisIOLive(String live_rid,ServletContext application){
		LiveInfo liveInfo = new LiveInfo();
		Map liveMap = new HashMap();
		try {
			liveMap = redisBDBService.HGETALL("SLIVE:"+live_rid);
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("redis connection exception redis, method:liveStreamServiceImpl.redisIOLive");
			if(Commonutils.checkRep(Constants.Code_redisB_Con_Exc, 100, application)){
				ThreadManagerUtil.getInstance().execute(new Report("redisB connect exception", "liveStreamServiceImpl.redisIOLive", 3));
			}
		}
		try {
			if (null != liveMap ){
				liveInfo.setId(null == liveMap.get("id")?null:liveMap.get("id").toString());
				liveInfo.setRid(null == liveMap.get("rid")?null:liveMap.get("rid").toString());
				liveInfo.setLiveName(null == liveMap.get("liveName")?null:liveMap.get("liveName").toString());
				String liveStatus = (null == liveMap.get("liveStatus")?"0":liveMap.get("liveStatus").toString());
				liveInfo.setLiveStatus(null == liveStatus?0:Integer.decode(liveStatus));
				String liveSwitch = (null == liveMap.get("liveSwitch")?"0":liveMap.get("liveSwitch").toString());
				liveInfo.setLiveSwitch(null == liveSwitch?0:Integer.decode(liveSwitch));
				String onlineCount = (null == liveMap.get("onlineCount")?"0":liveMap.get("onlineCount").toString());
				liveInfo.setOnlineCount(null == onlineCount?0:Integer.decode(onlineCount));
				liveInfo.setUserServerType(null == liveMap.get("user_server_type")?0:Integer.parseInt(liveMap.get("user_server_type").toString()));
				try {
					SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					if(null != liveMap.get("start_against") && null != liveMap.get("end_against")){
						Date start = sdf1.parse(liveMap.get("start_against").toString());
						Date end = sdf1.parse(liveMap.get("end_against").toString());
						liveInfo.setStart_against(start);
						liveInfo.setEnd_against(end);
					}
					if(null != liveMap.get("createTime") && null != liveMap.get("createTime")){
						Date createTime = sdf1.parse(liveMap.get("createTime").toString());
						liveInfo.setCreateTime(createTime);
					}
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("redis存储live时时间格式转换错误");
					if(Commonutils.checkRep(Constants.Code_RunT_Exc, 100, application)){
						ThreadManagerUtil.getInstance().execute(new Report("redis connect exception", "liveStreamServiceImpl.redisIOLive", 3));
					}
					
				}
				if(null == liveMap.get("liveCoverUrl") || "".equals(liveMap.get("liveCoverUrl"))){
					liveInfo.setLiveCoverUrl(null);
				}else{
					liveInfo.setLiveCoverUrl(liveMap.get("liveCoverUrl").toString());
				}
				liveInfo.setUserId(null == liveMap.get("userId")?null:liveMap.get("userId").toString());
				if(!"".equals(liveMap.get("pushCode")) && null != liveMap.get("pushCode")){
					liveInfo.setPushCode(liveMap.get("pushCode").toString());
				}
			}else{	//reides无数据，查询mysql
				try {
					liveInfo = liveInfoServiceImpl.selectByRid(live_rid);
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("sql connection exception redis, method:liveStreamServiceImpl.redisIOLive");
				}
				if (liveInfo==null){
					return liveInfo;
				}
				Map inLiveMap = new HashMap();
				inLiveMap.put("id", liveInfo.getId());
				inLiveMap.put("rid", liveInfo.getRid());
				inLiveMap.put("liveName", liveInfo.getLiveName());
				inLiveMap.put("liveStatus", null == liveInfo.getLiveStatus()?"0":liveInfo.getLiveStatus().toString());
				inLiveMap.put("liveSwitch", null == liveInfo.getLiveSwitch()?"0":liveInfo.getLiveSwitch().toString());
				inLiveMap.put("onlineCount", null == liveInfo.getOnlineCount()?"0":liveInfo.getOnlineCount().toString());
				inLiveMap.put("liveCoverUrl", (null == liveInfo.getLiveCoverUrl()?"":liveInfo.getLiveCoverUrl()));
				inLiveMap.put("userId", liveInfo.getUserId());
				inLiveMap.put("pushCode", null == liveInfo.getPushCode()?"":liveInfo.getPushCode());
				inLiveMap.put("user_server_type", null == liveInfo.getUserServerType()?"0":liveInfo.getUserServerType().toString());
				SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				if(null != liveInfo.getEnd_against() && null != liveInfo.getStart_against()){
					String st = sdf2.format(liveInfo.getStart_against());
					String ed = sdf2.format(liveInfo.getEnd_against());
					inLiveMap.put("start_against", st);
					inLiveMap.put("end_against", ed);
				}
				if(null != liveInfo.getCreateTime()){
					String createTime = sdf2.format(liveInfo.getCreateTime());
					inLiveMap.put("createTime", createTime);
				}
				try {
					redisBDBService.HSET("SLIVE:" + live_rid, inLiveMap,8); //入 redis库， 有效期5s
					//LogUtils.info("redisDBService.HSET SUCCESS,live_rid:"+live_rid);
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("redisBDBService.HSET ERROR,live_rid:"+live_rid);
				}
			}
			return liveInfo;
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("catch redisIOLive error,liveID:"+liveInfo.getId());
			return liveInfo;
		}
		
	}
	
	/* 特殊情况下 立即修改redis中缓存直播的属性
	 * time 2018年1月22日16:21:38
	 * @param liveFlag(0解禁  1开始  2 结束  3删除 4禁用)
	 */
	public int liveRedisOp(String live_rid,int liveFlag){
		return 0;
	}
	
	/*
	 * redis缓存录像
	 * @time 2018-1-20 17:50:27
	 * 时效 20分钟 
	 * @property:缓存属性   id,rid,videoName,originalName videoStatus videoSwitch userId
	 * 若后期使用到对象较多属性 可以使用序列化SerializeUtil 全部存储到redis
	 */
	private VideoInfo redisIOVideo(String videoSourveName,ServletContext application){
		Map videoMap = new HashMap();
		try {
			videoMap = redisBDBService.HGETALL("SVIDEO:"+videoSourveName);
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("redisB connection exception redis, method:liveStreamServiceImpl.redisIOVideo");
		}
		VideoInfo videoInfo = new VideoInfo();
		try {
			if (null != videoMap ){
				videoInfo.setId(null == videoMap.get("id")?null:videoMap.get("id").toString());
				videoInfo.setRid(null == videoMap.get("rid")?null:videoMap.get("rid").toString());
				videoInfo.setVideoName(null == videoMap.get("videoName")?null:videoMap.get("videoName").toString());
				videoInfo.setOriginalName(null == videoMap.get("originalName")?null:videoMap.get("originalName").toString());
				String videoStatus = (null == videoMap.get("videoStatus")?"0":videoMap.get("videoStatus").toString());
				videoInfo.setVideoStatus(null == videoStatus?0:Integer.decode(videoStatus));
				String videoSwitch = (null == videoMap.get("videoSwitch")?"0":videoMap.get("videoSwitch").toString());
				videoInfo.setVideoSwitch(null == videoSwitch?0:Integer.decode(videoSwitch));
				videoInfo.setUserId(null == videoMap.get("userId")?null:videoMap.get("userId").toString());
				videoInfo.setUserServerType(null == videoMap.get("user_server_type")?0:Integer.parseInt(videoMap.get("user_server_type").toString()));
				videoInfo.setVideoPass(null == videoMap.get("video_pass")?0:Integer.parseInt(videoMap.get("video_pass").toString()));
				try {
					if(null != videoMap.get("start_against") && null != videoMap.get("end_against")){
						SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						Date start = sdf1.parse(videoMap.get("start_against").toString());
						Date end = sdf1.parse(videoMap.get("end_against").toString());
						videoInfo.setStart_against(start);
						videoInfo.setEnd_against(end);
					}
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("redis存储live时时间格式转换错误");
					if(Commonutils.checkRep(Constants.Code_RunT_Exc, 100, application)){
						ThreadManagerUtil.getInstance().execute(new Report("redis connect exception", "liveStreamController.redisIOVideo", 3));
					}
				}
				if(!"".equals(videoMap.get("pushCode")) && null != videoMap.get("pushCode")){
					videoInfo.setPush_code(videoMap.get("pushCode").toString());
				}
			}else{	//reides无数据，查询mysql
				try {
					videoInfo = videoInfoServiceImpl.selectByOriginalName(videoSourveName);
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("sql connection exception redis, method:liveStreamServiceImpl.redisIOVideo");
				}
				if (videoInfo==null){
					videoInfo = videoInfoServiceImpl.selectByRid(videoSourveName);
					if(videoInfo == null){
						return videoInfo;
					}
				}
				Map inVideoMap = new HashMap();
				inVideoMap.put("id", videoInfo.getId());
				inVideoMap.put("rid", videoInfo.getRid());
				inVideoMap.put("videoName", videoInfo.getVideoName());
				inVideoMap.put("originalName", null == videoInfo.getOriginalName()?"":videoInfo.getOriginalName());
				inVideoMap.put("videoStatus", null == videoInfo.getVideoStatus()?"0":videoInfo.getVideoStatus().toString());
				inVideoMap.put("videoSwitch", null == videoInfo.getVideoSwitch()?"0":videoInfo.getVideoSwitch().toString());
				inVideoMap.put("userId", videoInfo.getUserId());
				inVideoMap.put("user_server_type", null == videoInfo.getUserServerType()?"0":videoInfo.getUserServerType().toString());
				inVideoMap.put("video_pass", null == videoInfo.getVideoPass()?"0":videoInfo.getVideoPass().toString());
				inVideoMap.put("pushCode", null == videoInfo.getPush_code()?"":videoInfo.getPush_code());
				if(null != videoInfo.getEnd_against() && null != videoInfo.getStart_against()){
					SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String st = sdf2.format(videoInfo.getStart_against());
					String ed = sdf2.format(videoInfo.getEnd_against());
					inVideoMap.put("start_against", st);
					inVideoMap.put("end_against", ed);
				}
				try {
					redisBDBService.HSET("SVIDEO:" + videoSourveName, inVideoMap,8); //入 redis库， 有效期5s
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("redisB connection exception redis, method:liveStreamServiceImpl.redisIOVideo");
				}
			}
			return videoInfo;
		} catch (Exception e) {
			// TODO: handle exception
			return videoInfo;
		}
	}
	
	/*
	 * redis缓存录像
	 * @time 2018-1-20 17:50:27
	 * 时效 20分钟 
	 * @property:缓存属性   id,rid,videoName,originalName videoStatus videoSwitch userId
	 * 若后期使用到对象较多属性 可以使用序列化SerializeUtil 全部存储到redis
	 */
	private VideoupInfo redisIOVideoUP(String rid,ServletContext application){
		Map videoMap = new HashMap();
		try {
			videoMap = redisBDBService.HGETALL("SVIDEOUP:"+rid);
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("redisB connection exception redis, method:liveStreamServiceImpl.redisIOVideoUP");
		}
		VideoupInfo videoupInfo = new VideoupInfo();
		try {
			if (null != videoMap ){
				videoupInfo.setId(null == videoMap.get("id")?null:videoMap.get("id").toString());
				videoupInfo.setRid(null == videoMap.get("rid")?null:videoMap.get("rid").toString());
				videoupInfo.setVideoName(null == videoMap.get("videoName")?null:videoMap.get("videoName").toString());
				videoupInfo.setOriginalName(null == videoMap.get("originalName")?null:videoMap.get("originalName").toString());
				String videoStatus = (null == videoMap.get("videoStatus")?"0":videoMap.get("videoStatus").toString());
				videoupInfo.setVideoStatus(null == videoStatus?0:Integer.decode(videoStatus));
				String videoSwitch = (null == videoMap.get("videoSwitch")?"0":videoMap.get("videoSwitch").toString());
				videoupInfo.setVideoSwitch(null == videoSwitch?0:Integer.decode(videoSwitch));
				videoupInfo.setUserId(null == videoMap.get("userId")?null:videoMap.get("userId").toString());
				videoupInfo.setUserServerType(null == videoMap.get("user_server_type")?0:Integer.parseInt(videoMap.get("user_server_type").toString()));
				videoupInfo.setVideoPass(null == videoMap.get("video_pass")?0:Integer.parseInt(videoMap.get("video_pass").toString()));
				/*try {
					if(null != videoMap.get("start_against") && null != videoMap.get("end_against")){
						SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						Date start = sdf1.parse(videoMap.get("start_against").toString());
						Date end = sdf1.parse(videoMap.get("end_against").toString());
					}
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("redis存储live时时间格式转换错误");
				}*/
				if(!"".equals(videoMap.get("pushCode")) && null != videoMap.get("pushCode")){
					videoupInfo.setPush_code(videoMap.get("pushCode").toString());
				}
			}else{	//reides无数据，查询mysql
				try {
					videoupInfo = videoupInfoServiceImpl.selectByRid(rid);
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("sql connection exception redis, method:liveStreamServiceImpl.redisIOVideoUP");
				}
				if (videoupInfo==null){
					return videoupInfo;
				}
				Map inVideoupMap = new HashMap();
				inVideoupMap.put("id", videoupInfo.getId());
				inVideoupMap.put("rid", videoupInfo.getRid());
				inVideoupMap.put("videoName", videoupInfo.getVideoName());
				inVideoupMap.put("originalName", null == videoupInfo.getOriginalName()?"":videoupInfo.getOriginalName());
				inVideoupMap.put("videoStatus", null == videoupInfo.getVideoStatus()?"0":videoupInfo.getVideoStatus().toString());
				inVideoupMap.put("videoSwitch", null == videoupInfo.getVideoSwitch()?"0":videoupInfo.getVideoSwitch().toString());
				inVideoupMap.put("userId", videoupInfo.getUserId());
				inVideoupMap.put("user_server_type", null == videoupInfo.getUserServerType()?"0":videoupInfo.getUserServerType().toString());
				inVideoupMap.put("video_pass", null == videoupInfo.getVideoPass()?"0":videoupInfo.getVideoPass().toString());
				/*if(null != videoupInfo.getEnd_against() && null != videoupInfo.getStart_against()){
					SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String st = sdf2.format(videoupInfo.getStart_against());
					String ed = sdf2.format(videoupInfo.getEnd_against());
					inVideoupMap.put("start_against", st);
					inVideoupMap.put("end_against", ed);
				}*/
				inVideoupMap.put("pushCode", null == videoupInfo.getPush_code()?"":videoupInfo.getPush_code());
				try {
					redisBDBService.HSET("SVIDEOUP:" + rid, inVideoupMap,8); //入 redis库， 有效期5s
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("redisB connection exception redis, method:liveStreamServiceImpl.redisIOVideoUP");
				}
			}
			return videoupInfo;
		} catch (Exception e) {
			// TODO: handle exception
			return videoupInfo;
		}
	}
	
	/**
	 * 规则鉴权
	 * 直播推流和播放都可以调用此方法
	 * @param paramStream
	 * @return AuthReturn  res -- 1:成功  0：失败   
	 *                     liveId
	 */
	private AuthReturn authComm(ParamStream paramStream,int flag, UserInfo userInfo,ServletContext application){
		try {
			// 后期播放鉴权 和 推流鉴权 数据可以放redis
			LiveInfo liveInfo = new LiveInfo();
			AuthReturn ar = new AuthReturn();
			ar.setRes(false);
			if (null == paramStream || StringUtils.isBlank(paramStream.getToken())
					|| StringUtils.isBlank(paramStream.getChannel()) || StringUtils.isBlank(paramStream.getSecret())) {
				return ar;
			}
			String live_stream = paramStream.getChannel();
			String live_rid = live_stream;
			if (live_stream.indexOf("_") >= 0) {// 有下划线：是转码流
				live_rid = live_stream.split("_")[0];
			}
			if (flag == 1) {
				liveInfo = redisIOLive(live_rid,application); // @time 2018年1月20日17:25:20
													// 播放从redis中获取
			} else {
				liveInfo = liveInfoServiceImpl.selectByRid(live_rid);
			}
			// 数据为空
			if (null == userInfo || null == liveInfo) {
				LogUtils.info("信息为空");
				return ar;
			} else {
				// LogUtils.info("直播状态:liveStatus:"+liveInfo.getLiveStatus());
				ar.setLiveId(liveInfo.getId());
				ar.setUserId(liveInfo.getUserId());
				ar.setLiveStatus(liveInfo.getLiveStatus());
				ar.setOnlineCount(liveInfo.getOnlineCount());
				ar.setRid(liveInfo.getRid());
			}

			// 看用户状态是否正常
			if (userInfo.getUserStatus() >= 2) {
				LogUtils.info("用户停止、禁用不能推流播放:"+userInfo.getUserName());
				if(Commonutils.checkRep(Constants.Code_Arre_Exc+userInfo.getRid(), 100, application)){
					ThreadManagerUtil.getInstance().execute(new Report("user arrearage limit,userid:"+userInfo.getId()+",userName:"+userInfo.getUserName()+",liveRid:"+live_rid, "liveStreamServiceImpl.authComm", 1));
				}
				return ar;
			}

			// 播放状况控制：禁用不能推流播流
			if (liveInfo.getLiveSwitch() == null) {
				LogUtils.info("被禁用");
				return ar;
			}
			int liveSwitch = liveInfo.getLiveSwitch();
			if (liveSwitch == 0) {

			} else {
				LogUtils.info("被禁用");
				return ar;
			}
			// 验证2个参数 md5(token#stream_id#user_key)
			String md5str = paramStream.getToken() + "#" + liveInfo.getRid() + "#" + userInfo.getUserKey();
			md5str = MD5Utils.getMD5String(md5str);
			if (md5str.equals(paramStream.getSecret()) || md5str.substring(8, 24).equals(paramStream.getSecret())) {
				ar.setRes(true);
				if (null != liveInfo.getStart_against() && null != liveInfo.getEnd_against()) {
					//开始大于当前或者结束小于当前  即无效
					if(liveInfo.getStart_against().getTime() > new Date().getTime() || liveInfo.getEnd_against().getTime() < new Date().getTime()){
						LogUtils.info("live鉴全不通过，不在时效内，id:"+liveInfo.getId());
						ar.setRes(false);
					}
				}
				if(StringUtils.isNotBlank(liveInfo.getPushCode())){	//兼容处理直播记录中pushcode存在已久的老数据
					String pushCode = paramStream.getPush_code();
					if(flag == 1){
						pushCode = paramStream.getXstToken();
					}
					if(!StringUtils.isNotBlank(pushCode)){
						ar.setRes(false);
						//直播创建时间在防盗链上线时间之前的 允许通过
						if(null != liveInfo.getCreateTime() && StringUtils.isNotBlank(configInfo.getAntiLeechTime())){
							try {
								SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
								Date t = sdf.parse(configInfo.getAntiLeechTime());
								if(liveInfo.getCreateTime().before(t)){
									ar.setRes(true);
								}else{
									LogUtils.info("live鉴全不通过，pushcode(xstToken)未传入，id:"+liveInfo.getId());
								}
							} catch (Exception e) {
								// TODO: handle exception
								LogUtils.info("exception:pushcode");
							}
						}else{
							LogUtils.info("no live createTime return 0");
						}
					}else{
						if(!liveInfo.getPushCode().equals(pushCode)){
							LogUtils.info("live鉴全不通过，pushcode不匹配，id:"+liveInfo.getId());
							ar.setRes(false);
						}
					}
				}
			}else{
				LogUtils.info("md5str.equals(paramStream.getSecret())异常");
			}
			return ar;
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("live鉴全authCommon exception");
			return null;
		}
	}
	
	/*
	 * 新增防盗链功能
	 * 从redis中取出 防盗码和截止时间点 与url中做判断处理
	 * key ：时间戳 T+#+view_code(防盗码)+userRid(用户rid)
	 * type 1直播、2录像 3点播   -- 待启用
	 */
	@Deprecated
	private boolean antiLeech(ParamStream paramStream,UserInfo userInfo,int type){
		if(null == paramStream || null == userInfo){
			return false;
		}
		if(StringUtils.isNotBlank(paramStream.getAuth_play())){
			try {
				String timestamp = paramStream.getAuth_play().split("-0-0-")[0];
				String signUrl = paramStream.getAuth_play().split("-0-0-")[1];
				if(StringUtils.isNotBlank(timestamp) && StringUtils.isNotBlank(signUrl)){
					String redisKey = null;
					if(type == 1){
						redisKey = "Live_FD"+paramStream.getChannel();
					}else if(type == 2){
						redisKey = "Video_FD"+paramStream.getChannel();
					}else{
						redisKey = "Videoup_FD"+paramStream.getChannel();
					}
					String redisVal = redisDBService.GET(redisKey);
					if(null == redisVal){
						LogUtils.info("FDredis中值为空");
						return false;
					}
					String pushCode = redisVal.split("#")[0];
					String valid_time = redisVal.split("#")[1];
					if(Long.parseLong(valid_time) < System.currentTimeMillis()){	//防盗链时间过期
						LogUtils.info("FDtime过期,expire:"+valid_time);
						return false;
					}else{
						StringBuffer str = new StringBuffer();
						str.append(timestamp).append("#").append(pushCode).append(userInfo.getRid());
						String sign = MD5Utils.getMD5String(str.toString());
						if(null == sign){
							LogUtils.info("FDsign为null");
							return false;
						}else{
							if(!signUrl.equals(sign)){
								LogUtils.info("FDsign不一致,sign1:"+sign+",sign2:"+signUrl);
								return false;
							}
						}
					}
				}else{
					return false;
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		return true;
	}
	
	
	/**
	 * 播放鉴权 1:成功  0：失败
	 */
	@Override
	public int authPaly(ParamStream paramStream,ServletContext application) {
		//后期播放鉴权 和 推流鉴权 数据可以放redis
		
		String liveVy = paramStream.getChannel();		//流id
		LiveInfo liveInfo = redisIOLive(liveVy,application);
		if(null == liveInfo || StringUtils.isBlank(liveInfo.getUserId())){
			LogUtils.info("live is null:"+paramStream.getChannel());
			return 0;//	鉴权false
		}
		UserInfo userInfo = redisIOUser(liveInfo.getUserId(),2,application);
		if(null == userInfo){
			LogUtils.info("-- user null -- liveRid:"+paramStream.getChannel());
			return 0;
		}
		String token = paramStream.getToken();
		if(token.contains("_")){	//新地址类型 2018年12月10日14:49:47  token并非用户rid
			paramStream.setToken(userInfo.getRid());
		}
		if(token.contains("directauthentication")){
			LogUtils.info("no auth liveRid:"+paramStream.getChannel());
			paramStream.setToken(userInfo.getRid());
			return 1;//	鉴权直接让过
		}
		AuthReturn ar = authComm(paramStream,1,userInfo,application);	//	1 play
		int resValue = 0;
		
		if (ar.isRes()==false){
			resValue = 0;
			return resValue;
		}else{
			//如果正在直播 统计计算
			if (ar.getLiveStatus()==1){
				redisDBService.INCR(RDS_STATIS_OL_MAXVALUE+ar.getLiveId());
				resValue = 1;
			}else{
				//都还没开始推流就播放了
				//LogUtils.info("规则正确，但是还未开始推流，所以鉴权失败......ar.liveStatus:"+ar.getLiveStatus());
				resValue = 1;
			}
		}
			
		String jylimitKey = "JYLIMIT:"+liveInfo.getId();
		String jylimitVal = redisDBService.GET(jylimitKey);
		if(null != jylimitVal){
			if("0".equals(jylimitVal)){
				LogUtils.info("鉴全开关设置不通过,liveID:"+liveInfo.getId());
				return 0;
			}else{
				return 1;
			}
		}
		if(null != liveInfo.getOnlineCount() && liveInfo.getOnlineCount() >0){
			try {
				String key = "LPC:" + liveInfo.getRid();
				String onlineV = redisDBService.GET(key);
				if(null != onlineV){
					int onl = Integer.valueOf(onlineV);
					if(onl >= liveInfo.getOnlineCount()){
						LogUtils.info("-- live online overflow -- liveRid:"+paramStream.getChannel());
						return 0;
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				LogUtils.info("live online limit exception,liveRid:"+paramStream.getChannel());
			}
		}
		//从内存中拉取直播限制信息（时间、个数）
		//LogUtils.info("直播Channel:"+liveVy);
		//Map map = (Map) application.getAttribute(liveVy);
		Integer limitC = null == userInfo.getLimitCount()?null:Integer.parseInt(userInfo.getLimitCount().toString());
		if(null == limitC || limitC == -2){
			limitC = configInfo.getLimicount();
		}else if(limitC == -1){
			limitC = 10000001;
		}
		Map map = (Map) redisDBService.HGETS("LNUMBER:"+liveVy);
		if(map != null && !map.isEmpty()){
			Long timeStart = Long.valueOf(map.get("time").toString());
			//int countLive = Integer.parseInt(map.get("countLive").toString());
			//LiveInfo liveInfo = liveInfoServiceImpl.selectByIdRid(liveVy);
			int countLive = Integer.parseInt(null == redisDBService.GET("LPCOUNT:"+liveVy)?"1":redisDBService.GET("LPCOUNT:"+liveVy));
			if( null != liveInfo.getLiveSwitch() && liveInfo.getLiveSwitch() > 0){	//1.自己禁用 2被管理员禁用
				LogUtils.info(" forbidden liveRid:"+liveVy+";liveSwitch:"+liveInfo.getLiveSwitch());
				return resValue;
			}
			if((System.currentTimeMillis() - timeStart)/1000 <600 ){	//10分钟以内
				//LogUtils.info("当前使用票数:"+countLive);
				if(userInfo.getUserStatus() ==1 ){		//欠费用户限制
					if( countLive >= 10 ){
						LogUtils.info("user status 1,liveRid:"+liveVy);
						resValue = 0;
					}else{
						/*countLive ++;
						map.put("countLive", String.valueOf(countLive));*/
						resValue = 1;
						redisDBService.INCR("LPCOUNT:"+liveVy);
						//redisDBService.HSET("LNUMBER:"+liveVy, map,86400);
						//application.setAttribute(liveVy, map);
					}
				}else if(userInfo.getUserStatus() >= 2){	//停用、冻结
					LogUtils.info("user status >=2,liveRid:"+liveVy);
					resValue = 0;
				}else{	//未欠费用户
					//UserCallback userCallback = userCallbackServiceImpl.selectByIdCallback(userInfo.getId());
					UserCallback userCallback = redisIOUserCallBack(userInfo.getId(),application);	//从redis中获取
					int calF = 0;
					String callUrl = null;
					if(null != userCallback){
						callUrl = userCallback.getCallbackUrl();
						if(StringUtils.isNotBlank(callUrl)){
							calF = 1;
						}
						int isCall = isUseCall(1,userCallback);
						if(isCall == 1){
							callUrl = userCallback.getUserCallback();
							calF = 1;
						}
					}
					if(calF == 1){	//有回调地址 第三方
						//有回调地址,10分钟处理一次预警上报
						//获取视频云直播id
						//LogUtils.info("回调地址："+callUrl);
						if(null != liveInfo && StringUtils.isNotBlank(liveInfo.getId())){	//有回调地址情况（云播） 获取其对应的视频云直播id
							String liveID = liveInfo.getId();
							//LogUtils.info("直播id："+liveID);
							//Integer limitCount = (Integer) application.getAttribute(MD5Utils.getMD5String(liveID));//获取限制人数
							Integer limitCount = null;
							if(null != redisDBService.GET(MD5Utils.getMD5String(liveID))){
								try {
									limitCount = Integer.parseInt(redisDBService.GET(MD5Utils.getMD5String(liveID)));//获取限制人数
									//LogUtils.info("liveRid:"+liveVy+";limitCount:"+limitCount);
								} catch (Exception e) {
									// TODO: handle exception
									LogUtils.info("三方回调异常,liveRid:"+liveVy);
								}
							}
							//LogUtils.info("设置限制数："+limitCount);
							if(null != limitCount){
								if(limitCount == -1){	//无限制
									resValue = 1;
									//LogUtils.info("third无限制");
									/*countLive ++;
									map.put("countLive", String.valueOf(countLive));*/
									redisDBService.INCR("LPCOUNT:"+liveVy);
									//application.setAttribute(liveVy, map);
									//redisDBService.HSET("LNUMBER:"+liveVy, map, 86400);
								}else if(limitCount == 0){
									//限制不让通过
									resValue = 0;
									LogUtils.info("third limit 0，liveRid:"+liveVy);	//第三方规则
									if(Commonutils.checkRep(Constants.Code_AuWar0_Exc+userInfo.getRid(), 100, application)){
										ThreadManagerUtil.getInstance().execute(new Report("thrid authWaring limit 0,uid:"+userInfo.getId()+",liveRid:"+liveVy, "liveStreamServiceImpl.authPaly", 2));
									}
								}else if(limitCount == -2){
									//LogUtils.info("301");	//第三方未查到信息，但在视频云有直播信息，属于视频云用户mwlive创建直播
									if( countLive >=  limitC){
										LogUtils.info("third flat no data,number over liveRid:"+liveVy+";count:"+countLive);
										resValue = 0;
									}else{
										resValue = 1;
										/*countLive ++;
										map.put("countLive", String.valueOf(countLive));*/
										//application.setAttribute(liveVy, map);
										//redisDBService.HSET("LNUMBER:"+liveVy, map, 86400);
										redisDBService.INCR("LPCOUNT:"+liveVy);
									}
								}else if(limitCount >= limitC){
									if( countLive >= limitCount){
										LogUtils.info("thrid_limit onCount:"+limitCount+";liveRid:"+liveVy);
										resValue = 0;
									}else{
										resValue = 1;
										/*countLive ++;
										map.put("countLive", String.valueOf(countLive));*/
										redisDBService.INCR("LPCOUNT:"+liveVy);
									}
								}else{
									if(countLive >= limitC){
										resValue = 0;
										LogUtils.info("other thrid_limit onCount:"+limitCount+";liveRid:"+liveVy);
									}else{
										resValue = 1;
										/*countLive ++;
										map.put("countLive", String.valueOf(countLive));*/
										redisDBService.INCR("LPCOUNT:"+liveVy);
									}
								}
							}else{	//未设置则不限制 
								//Integer countTmp = configInfo.getLimitwarming() + 1;	//2018年11月21日11:06:20 此处更改为统一使用用户设置参数limicount
								if( countLive >= limitC ){	//预警
									LogUtils.info("thirdFlat do not limit:"+countLive+";liveRid:"+liveVy);
									String param = "yunLiveId="+ liveID +"&url="+configInfo.getlCoUrl()+"&type=1";
									final String callUrlF = callUrl;
									final String paramF = param;
									try {
										//取内存中上次预警时间
										String mdL = liveID+"mw";
										String timeSet = MD5Utils.getMD5String(mdL);
										final String tokenTmp = token;
										final String liveRidTmp = liveVy;
										final ServletContext appl = application;
										if(null != redisDBService.GET(timeSet)){		//application.getAttribute(timeSet)
											//long tOld = (long) application.getAttribute(timeSet);
											long tOld = Long.parseLong(redisDBService.GET(timeSet));
											if((System.currentTimeMillis() - tOld)/1000 > 600 ){	//10分钟内不再次预警
												//application.setAttribute(timeSet, System.currentTimeMillis());	//重新设置时间
												redisDBService.SET(timeSet, String.valueOf(System.currentTimeMillis()),86400);	//重新设置时间
												LogUtils.info("person number overflow,liveID:"+liveID);
												TimerTask task1 = new TimerTask() {
												      @Override
												      public void run() {
												    	 LogUtils.info("report data to："+callUrlF+"?"+paramF);
														 try {
															 String res = Commonutils.sendGet(callUrlF, paramF,10);
															 LogUtils.info("report data result："+res);
															 if(StringUtils.isBlank(res)){
																 if(Commonutils.checkRep(Constants.Code_AuWar_Exc+tokenTmp, 100, appl)){
																		ThreadManagerUtil.getInstance().execute(new Report("thrid authWaring limit 0,urid:"+tokenTmp+",liveRid:"+liveRidTmp, "liveStreamServiceImpl.authPaly", 2));
																	}
															 }
														 } catch (Exception e) {
															// TODO: handle exception
															 e.printStackTrace();
														 }
												      }
												    };
												Timer timer = new Timer();
												long period = 60*1000;
												timer.schedule(task1, period);	//延后30秒上报
											}
										} else { // 尚未设置预警时间 -- 首次预警 设置预警记录
											// application.setAttribute(timeSet,
											// System.currentTimeMillis());
											redisDBService.SET(timeSet, String.valueOf(System.currentTimeMillis()),
													86400); // 重新设置时间
											LogUtils.info("person number overflow,report now ");
											TimerTask task2 = new TimerTask() {
												@Override
												public void run() {
													LogUtils.info("report data to：" + callUrlF + paramF);
													// String res =
													// HttpRequest.sendGet(callUrlF,
													// paramF);
													try {
														String res = Commonutils.sendGet(callUrlF, paramF, 10);
														LogUtils.info("report data result：" + res);
														if (StringUtils.isBlank(res)) {
															if (Commonutils.checkRep(
																	Constants.Code_AuWar_Exc + tokenTmp, 100, appl)) {
																ThreadManagerUtil.getInstance().execute(new Report(
																		"thrid authWaring limit 0,urid:" + tokenTmp
																				+ ",liveRid:" + liveRidTmp,
																		"liveStreamServiceImpl.authPaly", 2));
															}
														}
													} catch (Exception e) {
														// TODO: handle
														// exception
														e.printStackTrace();
													}
												}
											};
											Timer timer = new Timer();
											long period = 60 * 1000;
											timer.schedule(task2, period); // 延后秒上报
										}
									} catch (Exception e) {
										// TODO: handle exception
										LogUtils.info("预警上报异常："+e);
									}
								}
								resValue = 1;	//放开 健全成功
								/*countLive ++;
								map.put("countLive", String.valueOf(countLive));
								redisDBService.HSET("LNUMBER:"+liveVy, map, 86400);*/
								//application.setAttribute(liveVy, map);
								redisDBService.INCR("LPCOUNT:"+liveVy);
							}
						}else{
							LogUtils.info("not find thirdPlat in yun has live:limit");
							resValue = 0;
						}
					}else{	//未设置三方预警回调处理
						UserServerInfo usf = redisUserServer(userInfo.getId(),application);
						if(null != usf && usf.getUserServerType() == 1){
							//大用户  不做基础限制 
							resValue = 1;
							redisDBService.INCR("LPCOUNT:"+liveVy);
						}else{
							//视频云正常小用户 走正常小用户限制流程
							if( countLive >= limitC ){
								LogUtils.info("limit Arrearage onCount:"+countLive);
								resValue = 0;
							}else{
								resValue = 1;
								/*countLive ++;
								map.put("countLive", String.valueOf(countLive));*/
								redisDBService.INCR("LPCOUNT:"+liveVy);
								//application.setAttribute(liveVy, map);
								//redisDBService.HSET("LNUMBER:"+liveVy, map, 86400);
							}
						}
					}
				}
			}else{	//超出十分钟 则重置时间、票数
				/*if(callUrl.length() >0 ){	//第三方用户
					if(countLive >= 3){		//预警数字限制
						//预警
						LogUtils.info("第三方限制:"+countLive);
						String param = "?yunLiveId="+ liveID +"&url="+lCoUrl;
						try {
							LogUtils.info("准备预警上报至："+callUrl+param);
							String res = HttpRequest.sendGet(callUrl, param);
							LogUtils.info("预警上报结果："+res);
						} catch (Exception e) {
							// TODO: handle exception
							LogUtils.info("预警上报异常："+e);
						}
					}
				}*/
				if(null != liveInfo && StringUtils.isNotBlank(liveInfo.getId())){	//有回调地址情况（云播） 获取其对应的视频云直播id
					String liveID = liveInfo.getId();
					//LogUtils.info("reset liveLimitInfo："+liveID);
					//application.removeAttribute(MD5Utils.getMD5String(liveID));
					redisDBService.DEL(MD5Utils.getMD5String(liveID));
				}
				map.put("time", String.valueOf(System.currentTimeMillis()));
				//map.put("countLive", "1");
				//application.setAttribute(liveVy, map);
				redisDBService.HSET("LNUMBER:"+liveVy, map, 86400);
				redisDBService.DEL("LPCOUNT:"+liveVy);
			}
		}else{	//内存中不存在，则新增
			Map map1 = new HashMap();
			map1.put("time", String.valueOf(System.currentTimeMillis()));
			//map1.put("countLive", "1");
			redisDBService.HSET("LNUMBER:"+liveVy, map1, 86400);
			redisDBService.INCR("LPCOUNT:"+liveVy);
			//application.setAttribute(liveVy, map1);
		}
		//欠费用户 观看并发控制 end
		//控制在线人数
		if (ar.getOnlineCount()!=null && ar.getOnlineCount()>0){
			String rtmpV = redisDBService.GET("SOLRT:"+ar.getRid());
			String hlsV = redisDBService.GET("SOLHL:"+ar.getRid());
			
			int rtmpVi = 0;
			int hlsVi = 0;
			
			if (rtmpV!=null && !"".equals(rtmpV)){
				rtmpVi =(Integer.parseInt(rtmpV));
			}
			
			if (hlsV!=null && !"".equals(hlsV)){
				hlsVi =(Integer.parseInt(hlsV));
			}
			
			int online_count = ar.getOnlineCount(); 
			int online_update = rtmpVi+hlsVi;

			if (online_update>online_count){
				//LogUtils.info("超过观看人数限制："+ar.getRid()+" 设置限制为："+online_count+" 目前最新数据为："+online_update);
				resValue = 0;
			}
		}
		return resValue;
	}
	/**
	 * 推流鉴权：1:成功  0：失败
	 */
	@Override
	public int authPublish(ParamStream paramStream,ServletContext application) {
		LiveInfo liveInfo = new LiveInfo();
		try {
			liveInfo = liveInfoServiceImpl.selectByRid(paramStream.getChannel());
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("sql connect exception,method:liveStreamServiceImpl.authPublish");
			if(Commonutils.checkRep(Constants.Code_Sql_Con_Exc, 100, application)){
				ThreadManagerUtil.getInstance().execute(new Report("sql connect exception", "liveStreamServiceImpl.authPublish", 3));
			}
		}
		if(null == liveInfo || StringUtils.isBlank(liveInfo.getUserId())){
			LogUtils.info("live is null");
			return 0;
		}
		UserInfo userInfo = redisIOUser(liveInfo.getUserId(),2,application);
		if(null == userInfo || StringUtils.isBlank(userInfo.getRid())){
			LogUtils.info("userinfo error");
			return 0;
		}
		paramStream.setToken(userInfo.getRid());
		AuthReturn ar = authComm(paramStream,0,userInfo,application);	//0推流
		//如果失败了，就直接失败吧
		if (ar.isRes()==false){
			return 0;
		}
		
		//push_code 验证
		if (StringUtils.isBlank(paramStream.getPush_code())){
			return 0;
		} 
		
		//LiveInfo liveInfo = redisIOLive(paramStream.getChannel());	// @time 2018年1月20日17:30:57 改用从redis获取
		if (liveInfo==null || !paramStream.getPush_code().equals(liveInfo.getPushCode())){
			return 0;
		}else{
			String tLive_key = "TLIVE:"+ liveInfo.getRid();
			if(StringUtils.isNotBlank(paramStream.getMwfrom())){
				if("transfer".equals(paramStream.getMwfrom())){
					redisDBService.SET(tLive_key, "1");	//来自源站的直播状态反馈
				}
				if("equipment".equals(paramStream.getMwfrom())){
					redisDBService.SET(tLive_key, "3");	//设备直播
				}
			}
			return 1;
		}
	}

	
	private void toRedis15(RedisDB15Obj obj){
		RedisDB15Obj dbObj = redisDB15_RID.HGETOBJ(obj.getId());
		if(dbObj==null){
			redisDB15_RID.SETOBJ(obj);
		}
	}


	/*
	 * @author wqs 
	 * @desc 新增探测直播源方法
	 */
	public int detector(String downHttpUrl,String liveID){
		boolean conn;
		conn = CheckM3u8(downHttpUrl);
		if(conn){
			return 1;	//正在直播
		}else{
			return 2;	//未在直播
		}
	}
	
	/**
	 * 判断一个链接是否有效
	 * @param urlStr
	 * @return
	 */
	protected boolean CheckM3u8(String urlStr){
		HttpURLConnection conn = null;
		try {
			URL urlval = new URL(urlStr);
			conn = (HttpURLConnection)urlval.openConnection();
			conn.setConnectTimeout(5000); //设置超时
			conn.setReadTimeout(5000);	
			if (conn.getResponseCode() == HttpURLConnection.HTTP_OK){
				return true;
			}else{
				
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (conn!=null){
				conn.disconnect();
				conn = null;
			}
		}
		return false;
	}
	
	@Override
    public int authVOD(ParamStream paramStream,ServletContext application) {
        /* 获取用户信息 */
        //UserInfo userInfo = userInfoServiceImpl.selectByRid(paramStream.getToken());
		UserInfo userInfo = redisIOUser(paramStream.getToken(),1,application);
        if (userInfo == null) {
        	LogUtils.info("[x] no user data，videoup error,token:" + paramStream.getToken());
            return 0;
        }

        if (userInfo.getUserStatus() >= 2) {
        	LogUtils.info("[x] user status>=2：token" + userInfo.getRid());
            return 0;
        }
        
        VideoupInfo videoupInfo = videoupInfoServiceImpl.selectByRid(paramStream.getChannel());
        int isLB = 0;
        CommonAuV cov = new CommonAuV();
        if (videoupInfo == null) {
        	//存在 点播上传到录像中的情况  需要再去录播表中查找记录
        	VideoInfo videoInfo = videoInfoServiceImpl.selectByRid(paramStream.getChannel());
        	if(null == videoInfo){
        		LogUtils.info("[x] no videoup in video！videoupID：" + paramStream.getChannel());
                return 0;
        	}else{
        		isLB = 1;
        		if (videoInfo.getVideoStatus() != 0 || videoInfo.getVideoSwitch() != 0 || (videoInfo.getVideoPass() !=1 && videoInfo.getVideoPass() !=5 && videoInfo.getVideoPass() !=21 && videoInfo.getVideoPass() !=17)) {
                	LogUtils.info("[x] videoName：" + videoInfo.getOriginalName() + "，VideoSwitch：" + videoInfo.getVideoSwitch() + "，VideoStatus：" + videoInfo.getVideoStatus() + "，VideoPass：" + videoInfo.getVideoPass());
                    return 0;
                }
        		/*
        		 * 上传到录播中情况 
        		 */
        		ObjectConvert.entityToDTO(videoInfo,cov);
        		int res = antiLeech(paramStream,cov,2);
                if(res == 0){
                	return 0;
                }
        	}
        }else{
            /* 获取视频信息 */
            if (videoupInfo.getVideoStatus() != 0 || videoupInfo.getVideoSwitch() != 0 || (videoupInfo.getVideoPass() !=1 && videoupInfo.getVideoPass() !=5 && videoupInfo.getVideoPass() !=21 && videoupInfo.getVideoPass() !=17)) {
            	LogUtils.info("[x] videoupName：" + videoupInfo.getOriginalName() + "，VideoUpSwitch：" + videoupInfo.getVideoSwitch() + "，VideoUpStatus：" + videoupInfo.getVideoStatus());
                return 0;
            }
            cov = new CommonAuV();
    		ObjectConvert.entityToDTO(videoupInfo,cov);
    		int res = antiLeech(paramStream,cov,3);
            if(res == 0){
            	return 0;
            }
        }
        return 1;
    }
	
	// 点播 和录像 防盗链 2018-7-26 17:28:19
	public int antiLeech(ParamStream paramStream,CommonAuV cov,int type){
        try {
        	if(StringUtils.isNotBlank(cov.getPush_code())){
            	String pushCode = paramStream.getXstToken();
            	if(!StringUtils.isNotBlank(pushCode)){
            		LogUtils.info("vd防盗链:cdn传递pushcode为空，viID:"+cov.getId());
            		return 0;
            	}
            	if(!cov.getPush_code().equals(pushCode)){
            		LogUtils.info("vd防盗链:pushCode不一致,p1:"+pushCode+",p2:"+cov.getPush_code());
            		return 0;
            	}
            }
        	if(type == 3){	//点播
        		if(null != cov.getBeginTime() && null != cov.getEndTime()){	//设置了时效机制
            		if(cov.getBeginTime().getTime() > new Date().getTime() || cov.getEndTime().getTime() < new Date().getTime()){
    					LogUtils.info("vd防盗链:不在时效内,vid:" + cov.getId());
    					return 0;
    				}
            	}
        	}else{
        		if(null != cov.getStart_against() && null != cov.getEnd_against()){	//设置了时效机制
            		if(cov.getStart_against().getTime() > new Date().getTime() || cov.getEnd_against().getTime() < new Date().getTime()){
    					LogUtils.info("vd防盗链:不在时效内,vid:" + cov.getId());
    					return 0;
    				}
            	}
        	}
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("录像防盗链鉴全异常");
			return 0;
		}
        return 1;
	}
	
    @Override
    public int authVideo(ParamStream paramStream,ServletContext application) {
        /* 获取用户信息 */
        //UserInfo userInfo = userInfoServiceImpl.selectByRid(paramStream.getToken());
    	/* 获取视频信息 */
    	String videoSourveName = paramStream.getOrgName();
    	if(StringUtils.isBlank(videoSourveName)){
    		return 0;
    	}
		VideoInfo videoInfo = redisIOVideo(videoSourveName,application);
		if (videoInfo == null) {
        	LogUtils.info("[x] not find videoInfo，videoName：" + videoSourveName);
            return 0;
        }else{
        	String md5Val = MD5Utils.getMD5String(videoInfo.getRid()+"bk");
        	if(StringUtils.isNotBlank(paramStream.getSourceType())){
    			if(md5Val.equals(paramStream.getSourceType()) || md5Val == paramStream.getSourceType()){
    				return 1;	//直通
    			}else{
    				LogUtils.info("录播鉴全直通签名不匹配，md5Val:"+md5Val+";sourceType:"+paramStream.getSourceType());
    			}
    		}
        }
        if (videoInfo.getVideoStatus() != 0 || videoInfo.getVideoSwitch() != 0 || videoInfo.getVideoPass() != 1) {
        	LogUtils.info("[x] videoName：" + videoInfo.getOriginalName() + "，VideoSwitch：" + videoInfo.getVideoSwitch() + "，VideoStatus：" + videoInfo.getVideoStatus());
            return 0;
        }
        //云播录像播放兼容处理
        UserInfo userInfo = redisIOUser(videoInfo.getUserId(),2,application);
        String isYB = redisDBService.GET("ISYB");
        if(null != isYB && isYB.equals("1")){
        	if(userInfo.getId().equals("817433040745618657") || userInfo.getId().equals("817433040735924819") || userInfo.getId().equals("817433040738694950")){
        		return 1;
        	}
        }
        CommonAuV cov = new CommonAuV();
		ObjectConvert.entityToDTO(videoInfo,cov);
		int res = antiLeech(paramStream,cov,2);
        if(res == 0){
        	return 0;
        }
        if (userInfo == null) {
        	LogUtils.info("[x] no user data,video token ！" + paramStream.getToken());
            return 0;
        }

        if (userInfo.getUserStatus() >= 2) {
        	LogUtils.info("[x] user status>=2：" + userInfo.getRid() + "，userStatus：" + userInfo.getUserStatus());
            return 0;
        }
        
        return 1;
    }

	
	public static void main(String[] args){
		/*VideoInfo vi = new VideoInfo();
		vi.setId("20");
		vi.setAcodec(1);
		vi.setResolution("asf");
		vi.setBeginTime(new Date());
		VideoInfoMwCloud viC = new VideoInfoMwCloud();
		BeanUtils.copyProperties(vi, viC);
		System.out.println(viC.getId());*/
	}

	@Override
	public int authTest(ParamStream paramStream,int flag,ServletContext application) {
		// TODO Auto-generated method stub
		UserInfo userInfo = redisIOUser(paramStream.getToken(),1,application);
		String live_stream = paramStream.getChannel();
		String live_rid = live_stream;
		if (live_stream.indexOf("_")>=0){//有下划线：是转码流
			live_rid = live_stream.split("_")[0];
		}
		if(flag == 2){
			LiveInfo liveInfo = redisIOLive(live_rid,application);	//@time 2018年1月20日17:25:20  播放从redis中获取
		}else if(flag == 3){
			LiveInfo liveInfo = redisIOLive(live_rid,application);	
			userInfo = redisIOUser(paramStream.getToken(),1,application);
		}
		if(null != userInfo && StringUtils.isNotBlank(userInfo.getId())){
			return 1;
		}
		return 0;
	}

	@Override
	public int liveLimitCount(String liveId, Integer limitCount) {
		// TODO Auto-generated method stub
		try {
			String ridMD5 = MD5Utils.getMD5String(liveId);
			if(null == limitCount){
				limitCount = 0;
			}
			redisDBService.SET(ridMD5, limitCount.toString(), 86400);
			//application.setAttribute(ridMD5, limitCount);
		} catch (Exception e) {
			// TODO: handle exception
			return 1;
		}
		return 0;
	}

	@Override
	public int liveLimitUserCount(String userid, Integer limitCount) {
		// TODO Auto-generated method stub
		UserInfo userInfo = userInfoServiceImpl.selectByPrimaryKey(userid);
		if(null == userInfo){
			return -3;
		}
		String ridMD5 = MD5Utils.getMD5String(userid);
		if(null == limitCount){
			return -3;
		}else{
			if(limitCount == -2){
				return -2;
			}
		}
		redisDBService.SET("USERLIMIT:"+ridMD5, limitCount.toString());
		return limitCount;
	}
	
	/*
	 * 是否设置回调生效
	 * @param   int n   查看哪个设置
	 * @return 1/0
	 */
	public int isUseCall(int n,UserCallback userCallback){
		if(null != userCallback){
			/*
			 * @data 2018-9-5 10:45:31
			 * 增加统一回调处理  5 开始、6结束
			 * //1#0|2#0|3#0|4#0|5#0|6#0|7#0|8#0|9#0|10#0|11#0|12#0|13#0|14#0|15#0|16#0|17#0|18#0|19#0|20#0|21#0
			 */
			if(StringUtils.isNotBlank(userCallback.getCallbackType())){
				String arryTmp[] = userCallback.getCallbackType().split("\\|");
				if(null != arryTmp && arryTmp.length > n){
					n = n-1;	//取下标
					String ls = arryTmp[n].split("#")[1];
					if(StringUtils.isNotBlank(ls)){
						return Integer.parseInt(ls);
					}
				}
			}
		}
		return 0;
	}
	/*
	 * 回调type 直播鉴全 2   录像 3  点播4
	 * int type 传参类型   直播1 录像2 点播3
	 * @see com.facebac.yun.service.business.api.ILiveStreamService#checkAuthTrans(com.facebac.yun.model.api.ParamStream, int)
	 */
	@Override
	public int checkAuthTrans(ParamStream paramStream,int type,ServletContext application) {
		// TODO Auto-generated method stub
		UserInfo userInfo = redisIOUser(paramStream.getToken(),1,application);
		if(null != userInfo && StringUtils.isNotBlank(userInfo.getId())){
			UserCallback userCallback = redisIOUserCallBack(userInfo.getId(),application);
			if(null != userCallback ){
				String url =  null;
				int caFlag = 0;
				if(type == 1){
					url = userCallback.getLiveAuth();
				}else if(type == 2){
					url = userCallback.getVideoAuth();
				}else if(type == 3){
					url = userCallback.getVideoupAuth();
				}
				if(StringUtils.isNotBlank(url)){
					caFlag = 1;
				}
				int isCall = isUseCall(type+1,userCallback);
				if(isCall == 1){
					url = userCallback.getUserCallback();
					caFlag = 1;
				}
				if(caFlag != 1){
					return 1;	//未设置鉴全三方回调
				}
				LogUtils.info("type:"+type+"ip:"+paramStream.getClientip()+";playSource:"+paramStream.getPlaySource()+";xstToken:"+paramStream.getXstToken()+";userId:"+paramStream.getUserId()+";base_assemble:"+paramStream.getBase_assemble());
				//鉴权转移至第三方
				if(StringUtils.isBlank(paramStream.getIp()) || StringUtils.isBlank(paramStream.getPlaySource()) || 
						StringUtils.isBlank(paramStream.getUserId()) || StringUtils.isBlank(paramStream.getXstToken())){
					String charSet = "utf-8";
					String timeLimit = StringUtils.isNotBlank(userCallback.getIntervalTime())?userCallback.getIntervalTime():"3";
					String param = "ip="+paramStream.getClientip()+"&playSource="+paramStream.getPlaySource()+"&xstToken="+paramStream.getXstToken()+"&userId="+paramStream.getUserId()+"&type="+(type+1);//待参数 name=**&pass=**
					LogUtils.info("三方鉴全控制url:"+url+"?"+param);
					String res = Commonutils.sendPost(url, param, charSet,Integer.parseInt(StringUtils.isNotEmpty(timeLimit)?timeLimit:"3"));
					JSONObject obj = new JSONObject();
					if(StringUtils.isNotBlank(res)){
						obj = JSONObject.fromObject(res);
						if(obj.get("code").equals("-1")){	//失败
							return 0;
						}else{
							return 1;
						}
					}else{
						if(userCallback.getRequestTimes() != null){
							res = Commonutils.sendPost(url, param, charSet,Integer.parseInt(StringUtils.isNotEmpty(timeLimit)?timeLimit:"3"));
							if(StringUtils.isNotBlank(res)){
								obj = JSONObject.fromObject(res);
								if(obj.get("code").equals("-1")){	//失败
									return 0;
								}else{
									return 1;
								}
							}
						}
					}
					return 1;	//第三方鉴权放行
				}else{
					LogUtils.info("third plat(youwei) param error");
					return 1;	//第三方鉴权接口必要参数缺少（也有可能是cdn截取问题）
				}
			}else{
				return 1;	//未设置第三方鉴权
			}
		}
		return 1;	//系统内部错误
	}

	@Override
	public void commonAddPTi(ParamStream paramStream,String type,HttpServletRequest request,ServletContext application) {
		// TODO Auto-generated method stub
		//暂时存入redis 不考虑数据实时显示更新  按天区分
		String chanel = paramStream.getChannel();
		String token = paramStream.getToken();
		if(type.equals("1")){
			LiveInfo lf = redisIOLive(chanel,application);
			if(null == lf){
				return;
			}
			/*
			 * 直播鉴全增加人数到redis 用于记录并发在线人数   延时预判处理
			 */
			try {
				//LogUtils.info("============当前访问ip为=========:"+paramStream.getClientip());
				String ip = redisDBService.GET("LPC_IP:"+paramStream.getChannel()+":"+paramStream.getClientip());
				//LogUtils.info("=========redis-ip======="+ip);
				if(StringUtils.isBlank(ip)){	//首次访问--增加在线人数
					LogUtils.info(paramStream.getClientip()+"首次访问，增加并发数"+paramStream.getChannel());
					redisDBService.SET("LPC_IP:"+paramStream.getChannel()+":"+paramStream.getClientip(), paramStream.getClientip());	//直播结束后需要销毁
					redisDBService.expire("LPC_IP:"+paramStream.getChannel()+":"+paramStream.getClientip(), 1200);
					String key = "LPC:"+chanel;
					String key1 = "LPC1:"+chanel;	//当前一分钟内鉴全数
					String key2 = "LPC2:"+chanel;	//当前鉴全数
					String key3 = "LPC3:"+chanel;	//当前鉴全数
					String pc = redisDBService.GET(key);
					String pc1 = redisDBService.GET(key1);
					String pc2 = redisDBService.GET(key2);
					String pc3 = redisDBService.GET(key3);
					if(StringUtils.isBlank(pc)){
						redisDBService.INCR(key);
						redisDBService.expire(key, 18000);
					}else{
						redisDBService.INCR(key);
					}
					if(StringUtils.isBlank(pc1)){
						redisDBService.INCR(key1);
						redisDBService.expire(key1, 60);
					}else{
						redisDBService.INCR(key1);
					}
					if(StringUtils.isBlank(pc2)){
						redisDBService.INCR(key2);
						redisDBService.expire(key2, 120);
					}else{
						redisDBService.INCR(key2);
					}
					if(StringUtils.isBlank(pc3)){
						redisDBService.INCR(key3);
						redisDBService.expire(key3, 180);
					}else{
						redisDBService.INCR(key3);
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				LogUtils.info("直播鉴全增加播放次数异常"+chanel);
			}
			// 大用户增加播放次数
			if( null == lf.getUserServerType() || lf.getUserServerType() == 0|| lf.getUserServerType().equals("0")){
				return;
			}
		}else if(type.equals("2")){
			VideoInfo vf = redisIOVideo(chanel,application);
			if(null == vf || null == vf.getUserServerType() || vf.getUserServerType()==0 || vf.getUserServerType().equals("0")){
				return;
			}
		}else if(type.equals("3")){
			VideoupInfo vuf = redisIOVideoUP(chanel,application);
			if(null == vuf || null == vuf.getUserServerType() || vuf.getUserServerType() == 0 || vuf.getUserServerType().equals("0") ){
				return ;
			}
		}
		String vl = redisDBService.GET("UST:"+token);
		SimpleDateFormat smf = new SimpleDateFormat("yyyy-MM-dd");
		String nowT = smf.format(new Date());
		if(StringUtils.isNotBlank(vl) && StringUtils.isNotEmpty(vl)){
			String vl_1 = vl.substring(0,1);
			String vl_2 = vl.substring(2,vl.length());
			if(vl_1.equals("1")){
				redisDBService.INCR(nowT+":"+type+":"+vl_2);
			}
		}else{
			UserInfo userInfo = redisIOUser(token,1,application);
			if(null != userInfo && StringUtils.isNotBlank(userInfo.getId())){
				UserServerInfo userServerInfo = uSImpl.selectByPrimaryKey(userInfo.getId());
				if(null != userServerInfo){
					int ut = userServerInfo.getUserServerType();	//0小 1大
					if(ut == 1){
						String val = "1:"+ userInfo.getId();
						String key = "UST:"+token;
						redisDBService.SET(key, val);
						redisDBService.INCR(nowT+":"+type+":"+userInfo.getId());
					}
				}
			}
		}
	}

	@Override
	public boolean checkUST(String token, String chanel,ServletContext application) {
		// TODO Auto-generated method stub
		String vl = redisDBService.GET("UST:"+token);
		if(StringUtils.isNotBlank(vl) && StringUtils.isNotEmpty(vl)){
			if(vl.equals("1")){
				return true;
			}else{
				return false;
			}
		}else{
			UserInfo userInfo = redisIOUser(token,1,application);
			if(null != userInfo && StringUtils.isNotBlank(userInfo.getId())){
				UserServerInfo userServerInfo = uSImpl.selectByPrimaryKey(userInfo.getId());
				if(null != userServerInfo){
					int ut = userServerInfo.getUserServerType();	//0小 1大
					if(ut == 1){
						String key = "UST:"+token;
						redisDBService.SET(key, "1");
						return true;
					}else{
						return false;
					}
				}
			}
		}
		return false;
	}

	@Override
	public int streamswitch(String liveID,String type) {
		// TODO Auto-generated method stub
		try {
			String key = "JYLIMIT:"+liveID;
			if(type.equals("3")){
				String val = redisDBService.GET(key);
				if(null != val){
					return Integer.valueOf(val);
				}else{
					return 2;
				}
			}
			if(type.equals("4")){
				redisDBService.DEL(key);
				String val = redisDBService.GET(key);
				if(null == val){
					return 1;
				}else{
					return 2;
				}
			}
			redisDBService.SET(key, type, 43200);		//设置12小时
			return 1;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return 0;
	}

	@Override
	public String auPlayCount(String liveID) {
		// TODO Auto-generated method stub
		LiveInfo lf = liveInfoServiceImpl.selectByPrimaryKey(liveID);
		if(lf != null){
			String apc = redisDBService.GET("LPCOUNT:"+lf.getRid());
			String limitKey = "USERLIMIT:"+MD5Utils.getMD5String(lf.getUserId());
			String limitCount = redisDBService.GET(limitKey);
			return limitCount+" + "+apc;
		}
		return null;
	}
	
	
	
}


/**
 * 鉴权返回
 * @author leihua
 *
 */
class AuthReturn {
	private boolean res = false;
	private String liveId;
	private String rid;
	private String userId;
	private int liveStatus;
	private Integer onlineCount;
	
	public boolean isRes() {
		return res;
	}
	public void setRes(boolean res) {
		this.res = res;
	}
	public String getLiveId() {
		return liveId;
	}
	public void setLiveId(String liveId) {
		this.liveId = liveId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getLiveStatus() {
		return liveStatus;
	}
	public void setLiveStatus(int liveStatus) {
		this.liveStatus = liveStatus;
	}
	public Integer getOnlineCount() {
		return onlineCount;
	}
	public void setOnlineCount(Integer onlineCount) {
		this.onlineCount = onlineCount;
	}
	public String getRid() {
		return rid;
	}
	public void setRid(String rid) {
		this.rid = rid;
	}
	
}


