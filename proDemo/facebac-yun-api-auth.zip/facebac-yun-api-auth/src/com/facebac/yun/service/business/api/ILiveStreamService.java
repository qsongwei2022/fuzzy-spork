package com.facebac.yun.service.business.api;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.facebac.yun.model.api.ParamStream;

/**
 * @author  leihua
 * @date [2016年3月21日 上午9:10:16]
 * @version   1.0
 */
public interface ILiveStreamService {
	
	/**
	 * 播放鉴权  1:成功  0：失败
	 * @param streamParam
	 * @return
	 */
	public int authPaly(ParamStream paramStream,ServletContext application);
	
	/**
	 * 录像播放鉴权  1:成功  0：失败
	 * @param streamParam
	 * @return
	 */
	public int authVideo(ParamStream paramStream,ServletContext application);
	
	/**
	 * 点播播放鉴权  1:成功  0：失败
	 * @param streamParam
	 * @return
	 */
	public int authVOD(ParamStream paramStream,ServletContext application);
	
	/**
	 * 推流鉴权 1:成功  0：失败
	 * @param paramStream
	 * @return
	 */
	public int authPublish(ParamStream paramStream,ServletContext application);
	
	/**
	 * test
	 * @param paramStream
	 * @return
	 */
	public int authTest(ParamStream paramStream,int flag,ServletContext application);
	
	public int streamswitch(String liveID,String type);
	/**
	 * 限制设置接口
	 * @param liveID
	 * @return 1: 不限制  0：限制
	 */
	public int liveLimitCount(String liveRid, Integer limitCount);
	
	/**
	 * 限制数设置接口
	 * @param userid 用户 limitCount 限制数
	 * @return 限制数 -1 无限制  -2 使用默认限制   -3 错误   正整数  限制数
	 */
	public int liveLimitUserCount(String userid, Integer limitCount);
	
	public int checkAuthTrans(ParamStream paramStream,int type,ServletContext application);
	
	public void commonAddPTi(ParamStream paramStream,String type,HttpServletRequest request,ServletContext application);
	
	public boolean checkUST(String token,String chanel,ServletContext application);
	
	public String auPlayCount(String liveID);
}
