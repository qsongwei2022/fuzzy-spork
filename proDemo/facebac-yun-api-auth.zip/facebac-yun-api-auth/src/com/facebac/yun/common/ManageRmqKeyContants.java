package com.facebac.yun.common;

/**
 *
 * @Author LeiHua
 * @Date 2017年9月1日下午2:23:08
 * @Version
 *
 **/
public interface ManageRmqKeyContants {
	String RMQ_SYS_BROADCAST ="Q_MANAGE_SYS_BROADCAST"; //系统广播，无类型消息等
	String RMQ_LIVE_CREATE ="Q_MANAGE_LIVE_CREATE"; //直播创建
	String RMQ_LIVE_STATUS ="Q_MANAGE_LIVE_STATUS"; //直播状态
	String RMQ_VIDEO_CREATE ="Q_MANAGE_VIDEO_CREATE"; //录播创建
	String RMQ_RECORD_START = "Q_MANAGE_VIDEORECORD_START";//录制开始
}
