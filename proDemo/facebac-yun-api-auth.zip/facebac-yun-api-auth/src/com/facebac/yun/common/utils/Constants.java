package com.facebac.yun.common.utils;

public final class Constants {
	//私有构造方法
    private Constants() {}
 
    public static final String Code_redis_Con_Exc = "S_EXC_1001";		//redisA异常
    public static final String Code_redisB_Con_Exc = "S_EXCB_1001";		//redisB异常
    public static final String Code_Sql_Con_Exc = "S_EXC_1002";		//sql异常
    
    public static final String Code_AuWar_Exc = "S_EXC_1003_";		//三方控流预警
    public static final String Code_Arre_Exc = "S_EXC_1004_";		//用户欠费
    public static final String Code_RunT_Exc = "S_EXC_1005";		//运行时错误
    
    public static final String Code_AuWar0_Exc = "S_EXC_1006_";		//三方控流预警限制
}
