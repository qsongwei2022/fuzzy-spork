package com.facebac.yun.common;

/**
 *
 * @Author LeiHua
 * @Date 2017年9月19日上午10:58:50
 * @Version
 *
 **/
public interface ManageRedisKeyContants {
	String RDS_STATIS_OL_MAXVALUE = "SOLMX:"; //在线统计_直播最高值。数据只增不减。
}
