package com.facebac.yun.common.utils;
 
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;  
  
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;  
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
  
/** 
 * HMAC_SHA1 Sign生成器. 
 *  
 * 需要apache.commons.codec包 
 *  
 */  
public class HMAC_SHA1 {  
  
    private static final String HMAC_SHA1_ALGORITHM = "HmacSHA1";  
    private static final String HMAC_SHA1 = "HmacSHA1";  
    /** 
     * 使用 HMAC-SHA1 签名方法对data进行签名 
     *  
     * @param data 
     *            被签名的字符串 
     * @param key 
     *            密钥      
     * @return  
                      加密后的字符串 
     */  
    public static String genHMAC(String data, String key) {  
        byte[] result = null;  
        try {  
            //根据给定的字节数组构造一个密钥,第二参数指定一个密钥算法的名称    
            SecretKeySpec signinKey = new SecretKeySpec(key.getBytes(), HMAC_SHA1_ALGORITHM);  
            //生成一个指定 Mac 算法 的 Mac 对象    
            Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);  
            //用给定密钥初始化 Mac 对象    
            mac.init(signinKey);  
            //完成 Mac 操作     
            byte[] rawHmac = mac.doFinal(data.getBytes());  
            //result = Base64.encodeBase64(rawHmac);  
            StringBuilder sb=new StringBuilder();
		     for(byte b:rawHmac){
		    	 sb.append(byteToHexString(b));
		     }
		     return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println(e.getMessage());  
        } catch (InvalidKeyException e) {  
            System.err.println(e.getMessage());  
        }  
        return "";
    }  
    
    
    private static final String MAC_NAME = "HmacSHA1";
    private static final String ENCODING = "UTF-8";

    public static byte[] HmacSHA1Encrypt(String encryptText, String encryptKey) throws Exception {
        byte[] data = encryptKey.getBytes(ENCODING);
        // 根据给定的字节数组构造一个密钥,第二参数指定一个密钥算法的名称
        SecretKey secretKey = new SecretKeySpec(data, MAC_NAME);
        // 生成一个指定 Mac 算法 的 Mac 对象
        Mac mac = Mac.getInstance(MAC_NAME);
        // 用给定密钥初始化 Mac 对象
        mac.init(secretKey);

        byte[] text = encryptText.getBytes(ENCODING);
        // 完成 Mac 操作
        return mac.doFinal(text);
    }
    
    
    /**   
          * 生成签名数据   
          *    
          * @param data 待加密的数据   
          * @param key  加密使用的key   
          * @throws InvalidKeyException   
          * @throws NoSuchAlgorithmException   
          */
		public static String getSignature(String data,String key) throws Exception{
		     byte[] keyBytes=key.getBytes();
		     SecretKeySpec signingKey = new SecretKeySpec(keyBytes, HMAC_SHA1);
		     Mac mac = Mac.getInstance(HMAC_SHA1);
		     mac.init(signingKey);
		     byte[] rawHmac = mac.doFinal(data.getBytes());
		     StringBuilder sb=new StringBuilder();
		     for(byte b:rawHmac){
		    	 sb.append(byteToHexString(b));
		     }
		     return sb.toString();
		 }

		private static String byteToHexString(byte ib){
			char[] Digit={
			'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
			char[] ob=new char[2];
			ob[0]=Digit[(ib>>>4)& 0X0f];
			ob[1]=Digit[ib & 0X0F];
			String s=new String(ob);
			return s;
		}
    /** 
     * 测试 
     * @param args 
     */  
    public static void main(String[] args) {  
        String genHMAC = genHMAC("1554799912763,28268", "21890");  
        System.out.println(genHMAC.length()); 
        System.out.println(genHMAC);  
        try {
        	StringBuilder sb=new StringBuilder();
		     for(byte b:HmacSHA1Encrypt("123","1001")){
		    	 sb.append(byteToHexString(b));
		     }
		     System.out.println(sb.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
        try {
			System.out.println(getSignature("123","1001"));
		} catch (Exception e) {
			e.printStackTrace();
		}  
    }  
    
    /**
     * Title: MD5加密 生成32位md5码
     * Description: TestDemo
     * @author lu
     * @date 2016年6月23日 下午2:36:07
     * @param inStr
     * @return 返回32位md5码
     * @throws Exception
     */
    public static String md5Encode(String inStr) throws Exception {
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
            return "";
        }
        byte[] byteArray = inStr.getBytes("UTF-8");
        byte[] md5Bytes = md5.digest(byteArray);
        StringBuffer hexValue = new StringBuffer();
        for (int i = 0; i < md5Bytes.length; i++) {
            int val = ((int) md5Bytes[i]) & 0xff;
            if (val < 16) {
                hexValue.append("0");
            }
            hexValue.append(Integer.toHexString(val));
        }
        return hexValue.toString();
    }
    /**
     * Title: MD5加密
     * Description: TestDemo
     * @author lu
     * @date 2016年6月23日 下午2:43:31
     * @param inStr
     * @return
     */
    public static String string2MD5(String inStr) {
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
            return "";
        }
        char[] charArray = inStr.toCharArray();
        byte[] byteArray = new byte[charArray.length];

        for (int i = 0; i < charArray.length; i++)
            byteArray[i] = (byte) charArray[i];
        byte[] md5Bytes = md5.digest(byteArray);
        StringBuffer hexValue = new StringBuffer();
        for (int i = 0; i < md5Bytes.length; i++) {
            int val = ((int) md5Bytes[i]) & 0xff;
            if (val < 16)
                hexValue.append("0");
            hexValue.append(Integer.toHexString(val));
        }
        return hexValue.toString();

    }

    /**
     * Title: 加密解密算法 执行一次加密，两次解密
     * Description: TestDemo
     * @author lu
     * @date 2016年6月23日 下午2:37:29
     * @param inStr
     * @return
     */
    public static String convertMD5(String inStr) {

        char[] a = inStr.toCharArray();
        for (int i = 0; i < a.length; i++) {
            a[i] = (char) (a[i] ^ 't');
        }
        String s = new String(a);
        return s;

    }
    public static String md5Decode(String str) {
        return convertMD5(convertMD5(str));
    }
    
    /**
     * BASE64解密
     *
     * @param key
     * @return
     * @throws Exception
     */
    public static String decryptBASE64(String key) {
        byte[] bt;
        try {
            bt = (new BASE64Decoder()).decodeBuffer(key);
            return new String(bt,"gbk");//如果出现乱码可以改成： String(bt, "utf-8")或 gbk
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }
 
    /**
	 * 采用BASE64算法对字符串进行加密
	 * @param base 原字符串
	 * @return 加密后的字符串
	 */
	public static final String encode(String base){
		return encode(base.getBytes());
	}
	
	/**
	 * 采用BASE64算法对字节数组进行加密
	 * @param baseBuff 原字节数组
	 * @return 加密后的字符串
	 */
	public static final String encode(byte[] baseBuff){
		return new BASE64Encoder().encode(baseBuff);
	}
	
	/**
	 * 字符串解密，采用BASE64的算法
	 * @param encoder 需要解密的字符串
	 * @return 解密后的字符串
	 */
	public static final String decode(String encoder){
		try {
			BASE64Decoder decoder = new BASE64Decoder();
			byte[] buf = decoder.decodeBuffer(encoder);
			return new String(buf);
		} catch (Exception e) {
			
			return null;
		}
	}
}  
