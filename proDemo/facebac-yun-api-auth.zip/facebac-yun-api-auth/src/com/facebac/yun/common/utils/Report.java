package com.facebac.yun.common.utils;

public class Report implements Runnable {
	private String exception;
	private String extra;
	private Integer priority;
	public Report(String exception, String extra, Integer priority) {
		this.exception = exception;
		this.extra = extra;
		this.priority = priority;
	}

	@Override
	public void run() {
		Commonutils.report_abnormity(exception, extra, priority);
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	public String getExtra() {
		return extra;
	}

	public void setExtra(String extra) {
		this.extra = extra;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}
}
