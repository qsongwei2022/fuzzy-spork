package com.facebac.yun.common.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import net.sf.json.JSONObject;
import service.MwCloud_SMS_Send;
import service.Mw_SMS_Send;


/* @author WQS
 * @time 2018年1月20日16:29:31
 * @desc 序列化、反序列化
 */
public class Commonutils {
	private static int port;
	private static String url;
	static{
		try {
			url = PropertiesUtil.getProperties_1(
					"resources/system.properties", "report.abnormity.url");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		try {
			MBeanServer mBeanServer = null;
			ArrayList<MBeanServer> mBeanServers = MBeanServerFactory.findMBeanServer(null);
			if (mBeanServers.size() > 0) {
				for (MBeanServer _mBeanServer : mBeanServers) {
					mBeanServer = _mBeanServer;
					break;
					}
				}
			if(mBeanServer == null){
				throw new IllegalStateException("未发现关联的MBeanServer");
			}
			Set<ObjectName> objectNames = null;
			try {
				objectNames = mBeanServer.queryNames(new ObjectName("Catalina:type=Connector,*"), null);
			} catch (MalformedObjectNameException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			if (objectNames == null || objectNames.size() <= 0) {
				throw new IllegalStateException("没有发现JVM中关联的MBeanServer : "
						+ mBeanServer.getDefaultDomain() + " 中的对象名称.");
			}
			try {
				List list = new ArrayList(objectNames);
				ObjectName objectName = (ObjectName) list.get(0);
				String protocol = (String) mBeanServer.getAttribute(objectName, "protocol");
				if (protocol.equals("HTTP/1.1")) {
					int port = (Integer) mBeanServer.getAttribute(objectName, "port");
				}
				String scheme = (String) mBeanServer.getAttribute(objectName,"scheme");
				int cu_port = (int) mBeanServer.getAttribute(objectName,"port");
				port = cu_port;
			} catch (AttributeNotFoundException e) {
				e.printStackTrace();
			} catch (InstanceNotFoundException e) {
				e.printStackTrace();
			} catch (MBeanException e) {
				e.printStackTrace();
			} catch (ReflectionException e){
				e.printStackTrace();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	public static byte[] serialize(Object object) {
		ObjectOutputStream oos = null;
		ByteArrayOutputStream baos = null;
		try {
			// 序列化
			baos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(baos);
			oos.writeObject(object);
			byte[] bytes = baos.toByteArray();
			return bytes;
		} catch (Exception e) {
		}
		return null;
	}

	public static Object unserialize(byte[] bytes) {
		ByteArrayInputStream bais = null;
		try {
			// 反序列化
			bais = new ByteArrayInputStream(bytes);
			ObjectInputStream ois = new ObjectInputStream(bais);
			return ois.readObject();
		} catch (Exception e) {
		}
		return null;
	}
	
	/* @author WQS
	 * @time 2018-3-27 14:34:17
	 * @desc 根据ua辨识客户端
	 */	
	// \b 是单词边界(连着的两个(字母字符 与 非字母字符) 之间的逻辑上的间隔),    
    // 字符串在编译时会被转码一次,所以是 "\\b"    
    // \B 是单词内部逻辑间隔(连着的两个字母字符之间的逻辑上的间隔)    
    static String phoneReg = "\\b(ip(hone|od)|android|opera m(ob|in)i"    
            +"|windows (phone|ce)|blackberry"    
            +"|s(ymbian|eries60|amsung)|p(laybook|alm|rofile/midp"    
            +"|laystation portable)|nokia|fennec|htc[-_]"    
            +"|mobile|up.browser|[1-4][0-9]{2}x[1-4][0-9]{2})\\b";    
    static String tableReg = "\\b(ipad|tablet|(Nexus 7)|up.browser"    
            +"|[1-4][0-9]{2}x[1-4][0-9]{2})\\b";    
      
    //移动设备正则匹配：手机端、平板  
    static Pattern phonePat = Pattern.compile(phoneReg, Pattern.CASE_INSENSITIVE);    
    static Pattern tablePat = Pattern.compile(tableReg, Pattern.CASE_INSENSITIVE);    
        
    /** 
     * 检测是否是移动设备访问 
     *  
     * @Title: check 
     * @Date : 2014-7-7 下午01:29:07 
     * @param userAgent 浏览器标识 
     * @return true:移动设备接入，false:pc端接入 
     */  
    public static void check(String userAgent){
        if(null == userAgent){
            userAgent = "";    
        }
        // 匹配    
        Matcher matcherPhone = phonePat.matcher(userAgent);    
        Matcher matcherTable = tablePat.matcher(userAgent);    
        if(matcherPhone.find() || matcherTable.find()){
            System.out.println("true");   
        } else {    
        	System.out.println("false");
        }
        /*Pattern pattern = Pattern.compile(";\\s?(\\S*?\\s?\\S*?)\\s?(Build)?/");  
        Matcher matcher = pattern.matcher(userAgent);  
        String model = null;  
        if (matcher.find()) {  
            model = matcher.group(1).trim();
            System.out.println(model);
        }*/
    }
    
    /** Wap网关Via头信息中特有的描述信息 */
    private static String mobileGateWayHeaders[] = new String[] { "ZXWAP", // 中兴提供的wap网关的via信息，例如：Via=ZXWAP
                                                                            // GateWayZTE
                                                                            // Technologies，
            "chinamobile.com", // 中国移动的诺基亚wap网关，例如：Via=WTP/1.1
                                // GDSZ-PB-GW003-WAP07.gd.chinamobile.com (Nokia
                                // WAP Gateway 4.1 CD1/ECD13_D/4.1.04)
            "monternet.com", // 移动梦网的网关，例如：Via=WTP/1.1
                                // BJBJ-PS-WAP1-GW08.bj1.monternet.com. (Nokia
                                // WAP Gateway 4.1 CD1/ECD13_E/4.1.05)
            "infoX", // 华为提供的wap网关，例如：Via=HTTP/1.1 GDGZ-PS-GW011-WAP2
                        // (infoX-WISG Huawei Technologies)，或Via=infoX WAP
                        // Gateway V300R001 Huawei Technologies
            "XMS 724Solutions HTG", // 国外电信运营商的wap网关，不知道是哪一家
            "Bytemobile",// 貌似是一个给移动互联网提供解决方案提高网络运行效率的，例如：Via=1.1 Bytemobile OSN
                            // WebProxy/5.1
    };
    /** 电脑上的IE或Firefox浏览器等的User-Agent关键词 */
    private static String[] pcHeaders = new String[] { "Windows 98", "Windows ME", "Windows 2000", "Windows XP",
            "Windows NT", "Ubuntu" };
    /** 手机浏览器的User-Agent里的关键词 */
    private static String[] mobileUserAgents = new String[] { "Nokia", // 诺基亚，有山寨机也写这个的，总还算是手机，Mozilla/5.0
                                                                        // (Nokia5800
                                                                        // XpressMusic)UC
                                                                        // AppleWebkit(like
                                                                        // Gecko)
                                                                        // Safari/530
            "SAMSUNG", // 三星手机
                        // SAMSUNG-GT-B7722/1.0+SHP/VPP/R5+Dolfin/1.5+Nextreaming+SMM-MMS/1.2.0+profile/MIDP-2.1+configuration/CLDC-1.1
            "MIDP-2", // j2me2.0，Mozilla/5.0 (SymbianOS/9.3; U; Series60/3.2
                        // NokiaE75-1 /110.48.125 Profile/MIDP-2.1
                        // Configuration/CLDC-1.1 ) AppleWebKit/413 (KHTML like
                        // Gecko) Safari/413
            "CLDC1.1", // M600/MIDP2.0/CLDC1.1/Screen-240X320
            "SymbianOS", // 塞班系统的，
            "MAUI", // MTK山寨机默认ua
            "UNTRUSTED/1.0", // 疑似山寨机的ua，基本可以确定还是手机
            "Windows CE", // Windows CE，Mozilla/4.0 (compatible; MSIE 6.0;
                            // Windows CE; IEMobile 7.11)
            "iPhone", // iPhone是否也转wap？不管它，先区分出来再说。Mozilla/5.0 (iPhone; U; CPU
                        // iPhone OS 4_1 like Mac OS X; zh-cn) AppleWebKit/532.9
                        // (KHTML like Gecko) Mobile/8B117
            "iPad", // iPad的ua，Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X;
                    // zh-cn) AppleWebKit/531.21.10 (KHTML like Gecko)
                    // Version/4.0.4 Mobile/7B367 Safari/531.21.10
            "Android", // Android是否也转wap？Mozilla/5.0 (Linux; U; Android
                        // 2.1-update1; zh-cn; XT800 Build/TITA_M2_16.22.7)
                        // AppleWebKit/530.17 (KHTML like Gecko) Version/4.0
                        // Mobile Safari/530.17
            "BlackBerry", // BlackBerry8310/2.7.0.106-4.5.0.182
            "UCWEB", // ucweb是否只给wap页面？ Nokia5800
                        // XpressMusic/UCWEB7.5.0.66/50/999
            "ucweb", // 小写的ucweb貌似是uc的代理服务器Mozilla/6.0 (compatible; MSIE 6.0;)
                        // Opera ucweb-squid
            "BREW", // 很奇怪的ua，例如：REW-Applet/0x20068888 (BREW/3.1.5.20; DeviceId:
                    // 40105; Lang: zhcn) ucweb-squid
            "J2ME", // 很奇怪的ua，只有J2ME四个字母
            "YULONG", // 宇龙手机，YULONG-CoolpadN68/10.14 IPANEL/2.0 CTC/1.0
            "YuLong", // 还是宇龙
            "COOLPAD", // 宇龙酷派YL-COOLPADS100/08.10.S100 POLARIS/2.9 CTC/1.0
            "TIANYU", // 天语手机TIANYU-KTOUCH/V209/MIDP2.0/CLDC1.1/Screen-240X320
            "TY-", // 天语，TY-F6229/701116_6215_V0230 JUPITOR/2.2 CTC/1.0
            "K-Touch", // 还是天语K-Touch_N2200_CMCC/TBG110022_1223_V0801 MTK/6223
                        // Release/30.07.2008 Browser/WAP2.0
            "Haier", // 海尔手机，Haier-HG-M217_CMCC/3.0 Release/12.1.2007
                        // Browser/WAP2.0
            "DOPOD", // 多普达手机
            "Lenovo", // 联想手机，Lenovo-P650WG/S100 LMP/LML Release/2010.02.22
                        // Profile/MIDP2.0 Configuration/CLDC1.1
            "LENOVO", // 联想手机，比如：LENOVO-P780/176A
            "HUAQIN", // 华勤手机
            "AIGO-", // 爱国者居然也出过手机，AIGO-800C/2.04 TMSS-BROWSER/1.0.0 CTC/1.0
            "CTC/1.0", // 含义不明
            "CTC/2.0", // 含义不明
            "CMCC", // 移动定制手机，K-Touch_N2200_CMCC/TBG110022_1223_V0801 MTK/6223
                    // Release/30.07.2008 Browser/WAP2.0
            "DAXIAN", // 大显手机DAXIAN X180 UP.Browser/6.2.3.2(GUI) MMP/2.0
            "MOT-", // 摩托罗拉，MOT-MOTOROKRE6/1.0 LinuxOS/2.4.20 Release/8.4.2006
                    // Browser/Opera8.00 Profile/MIDP2.0 Configuration/CLDC1.1
                    // Software/R533_G_11.10.54R
            "SonyEricsson", // 索爱手机，SonyEricssonP990i/R100 Mozilla/4.0
                            // (compatible; MSIE 6.0; Symbian OS; 405) Opera
                            // 8.65 [zh-CN]
            "GIONEE", // 金立手机
            "HTC", // HTC手机
            "ZTE", // 中兴手机，ZTE-A211/P109A2V1.0.0/WAP2.0 Profile
            "HUAWEI", // 华为手机，
            "webOS", // palm手机，Mozilla/5.0 (webOS/1.4.5; U; zh-CN)
                        // AppleWebKit/532.2 (KHTML like Gecko) Version/1.0
                        // Safari/532.2 Pre/1.0
            "GoBrowser", // 3g GoBrowser.User-Agent=Nokia5230/GoBrowser/2.0.290
                            // Safari
            "IEMobile", // Windows CE手机自带浏览器，
            "WAP2.0"// 支持wap 2.0的
    };

    /**
     * 根据当前请求的特征，判断该请求是否来自手机终端，主要检测特殊的头信息，以及user-Agent这个header
     * 
     * @param request
     *            http请求
     * @return 如果命中手机特征规则，则返回对应的特征字符串
     */
    public static boolean isMobileDevice(String via, String userAgent) {
        boolean isMobile = false;
        boolean pcFlag = false;
        boolean mobileFlag = false;
        for (int i = 0; via != null && !via.trim().equals("") && i < mobileGateWayHeaders.length; i++) {
            if (via.contains(mobileGateWayHeaders[i])) {
                mobileFlag = true;
                break;
            }
        }
        for (int i = 0; !mobileFlag && userAgent != null && !userAgent.trim().equals("")
                && i < mobileUserAgents.length; i++) {
            if (userAgent.contains(mobileUserAgents[i])) {
                mobileFlag = true;
                break;
            }
        }
        for (int i = 0; userAgent != null && !userAgent.trim().equals("") && i < pcHeaders.length; i++) {
            if (userAgent.contains(pcHeaders[i])) {
                pcFlag = true;
                break;
            }
        }
        if (mobileFlag == true && pcFlag == false) {
            isMobile = true;
        }
        System.out.println("mobileFlag:"+mobileFlag);
        System.out.println("pcFlag:"+pcFlag);
        return isMobile;// false pc true mobile

    }

    /**
     * 判断是否为IOS系统访问
     * 
     * @param request
     * @return
     */
    public static boolean isIOSDevice(String userAgent) {
        boolean isMobile = false;
        final String[] ios_sys = { "iPhone", "iPad", "iPod" };
        for (int i = 0; !isMobile && userAgent != null && !userAgent.trim().equals("") && i < ios_sys.length; i++) {
            if (userAgent.contains(ios_sys[i])) {
                isMobile = true;
                break;
            }
        }
        System.out.println(isMobile);
        return isMobile;
    }

    /**
     * 判断是否是微信访问
     * 
     * @param request
     * @return
     */
    /*public static boolean isWeChat(String userAgent) {
        return userAgent == null || userAgent.indexOf("micromessenger") == -1 ? false : true;
    }*/
    
    public static String sendGet(String url, String param,Map<String,String> headersParamMap,int per) {
	     String result = "";
	     BufferedReader in = null;
	     try {
	         String urlNameString = null;
	         
	         if (param==null || "".equals(param.trim())){
	        	 urlNameString = url;
	         }else{
	        	 urlNameString = url + "?" + param;
	         }
	         
	         //LogUtils.info(" === http get url : "+urlNameString);
	         
	         URL realUrl = new URL(urlNameString);
	         // 打开和URL之间的连接  
	         // HttpURLConnection 可以得到状态
	         URLConnection connection = realUrl.openConnection();
	         // 设置通用的请求属性
	         if(per <= 0){
	        	 per = 10;
	         }
	         connection.setConnectTimeout(per*1000);
	         connection.setReadTimeout(per*1000);
	         connection.setRequestProperty("accept", "*/*");
	         connection.setRequestProperty("connection", "Keep-Alive");
	         connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
	         //connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0");  
	         if (headersParamMap!=null && headersParamMap.size()>0){
	        	 for(Map.Entry<String, String> entry:headersParamMap.entrySet()){
	        		 connection.setRequestProperty(entry.getKey(), entry.getValue());
	        	 }
	         }
	         
	         //打印请求头
	         Map<String,List<String>> requestMap =  connection.getRequestProperties();
	         //System.out.println("=====================>>请求头");
	         for (String key : requestMap.keySet()) {
	             //System.out.println(key + ">>" + requestMap.get(key));
	         }         
	         
	         // 建立实际的连接
	         connection.connect();
	         // 获取所有响应头字段
	         
	         Map<String, List<String>> map = connection.getHeaderFields();
	         // 遍历所有的响应头字段
	         //System.out.println("=====================>>响应头 ");
	         for (String key : map.keySet()) {
	             //System.out.println(key + "<< " + map.get(key));
	         }
	         // 定义 BufferedReader输入流来读取URL的响应
	         in = new BufferedReader(new InputStreamReader(
	                 connection.getInputStream()));
	         String line;
	         while ((line = in.readLine()) != null) {
	             result += line;
	         }
	     } catch (Exception e) {
	         System.out.println("发送GET请求出现异常！" + e);
	         e.printStackTrace();
	     }
	     // 使用finally块来关闭输入流
	     finally {
	         try {
	             if (in != null) {
	                 in.close();
	             }
	         } catch (Exception e2) {
	             e2.printStackTrace();
	         }
	     }
	     return result;
	 }
	 
	 public static String sendGet(String url, String param,int per) {
		 return sendGet(url,param,null,per);
	 }
	 
	 public static String sendGet(String url,int per) {
		 return sendGet(url,null,null,per);
	 }
	 
	 public static String sendPost(String url, Map<String, String> paramMap,String charSet,int per) {
			String param = null;
			if (paramMap != null && paramMap.size() > 0) {
				param = new String();
				for (Map.Entry<String, String> entry : paramMap.entrySet()) {
					String temp = "&" + entry.getKey() + "=" + entry.getValue();
					param = param + temp;
				}
				param = param.substring(1);
			}
			return sendPost(url, param, charSet,per);
		}

		public static String sendPost(String url, String param,String charSet,int per) {
			if(StringUtils.isBlank(charSet) || StringUtils.isEmpty(charSet)){
				charSet = "utf-8";
			}
			PrintWriter out = null;
			BufferedReader in = null;
			String result = "";
			try {
				URL realUrl = new URL(url);
				// 打开和URL之间的连接
				URLConnection conn = realUrl.openConnection();
				// 设置通用的请求属性
				conn.setRequestProperty("accept", "*/*");
				conn.setRequestProperty("connection", "Keep-Alive");
				conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
				conn.setRequestProperty("Accept-Charset", charSet);
				conn.setRequestProperty("contentType", charSet);
				if(per <= 0 ){
					per = 10;
				}
				conn.setConnectTimeout(per * 1000); // 设置超时
	            conn.setReadTimeout(per * 1000);
				// 发送POST请求必须设置如下两行
				conn.setDoOutput(true);
				conn.setDoInput(true);
				// 获取URLConnection对象对应的输出流
				out = new PrintWriter(conn.getOutputStream());

				// 发送请求参数
				if (param != null && !"".equals(param)) {
					out.print(param);
				}

				// flush输出流的缓冲
				out.flush();
				// 定义BufferedReader输入流来读取URL的响应
				in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String line;
				while ((line = in.readLine()) != null) {
					result += line;
				}
			} catch (Exception e) {
				LogUtils.info("发送 POST 请求出现异常！" + e.toString());
			}
			// 使用finally块来关闭输出流、输入流
			finally {
				try {
					if (out != null) {
						out.close();
					}
					if (in != null) {
						in.close();
					}
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
			return result;
		}
		
		/** 
		  * 发送 get请求 
		  */  
		 public static String httpGet(String url,int per) {
		     CloseableHttpClient httpclient = HttpClients.createDefault();
		     if(per <= 0){
		    	 per = 10;
		     }
		     /*httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, per*1000);
		     httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT,per*1000);*/
		     String resp = null;
		     try {
		         // 创建httpget.
		         //HttpGet httpget = new HttpGet("http://117.131.17.78:8080/sales/pricing?clientId=15d13842-f4a8-4b7c-8b30-221ec2f2a074");
		     	HttpGet httpget = new HttpGet(url);
		     	httpget.setHeader("Content-Type","application/json;charset=utf-8");
		         System.out.println("executing request " + httpget.getURI());  
		         // 执行get请求.    
		         CloseableHttpResponse response = httpclient.execute(httpget);
		         response.setHeader("Content-Type","application/json;charset=utf-8");
		         try {
		             // 获取响应实体    
		             HttpEntity entity = response.getEntity();  
		             System.out.println("--------------------------------------");  
		             // 打印响应状态
		             System.out.println(response.getStatusLine());  
		             if (entity != null) {
		                 // 打印响应内容长度    
		                 System.out.println("Response content length: " + entity.getContentLength());  
		                 // 打印响应内容
		                 resp = EntityUtils.toString(entity);
		                 System.out.println("Response content: " + resp);
		             }
		             System.out.println("------------------------------------");  
		         } finally {
		             response.close();  
		         }
		     } catch (ClientProtocolException e) {
		         e.printStackTrace();  
		     } catch (IOException e) {  
		         e.printStackTrace();  
		     } finally {  
		         // 关闭连接,释放资源    
		         try {
		             httpclient.close();  
		         } catch (IOException e) {  
		             e.printStackTrace();  
		         }
		     }
		     return resp;
		 }
		 
		 /** 
		  * @Description:使用HttpClient发送get请求 
		  * @author:wqs 
		  * @time:2018年1月12日 下午3:28:56
		  * @urlParam :目标服务器地址；params 请求参数;charset :编码 ； period：请求异常后 延时执行时间 times 请求次数
		  */  
		 public static String httpClientGet(String urlParam, Map<String, Object> params, String charset, Long period,int per) {
		     StringBuffer resultBuffer = null;  
		     HttpClient client = new DefaultHttpClient();
		     BufferedReader br = null;  
		     if(per <= 0){
		    	 per = 10;
		     }
		     client.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, per*1000);
		     client.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, per*1000);
		     // 构建请求参数  
		     StringBuffer sbParams = new StringBuffer();
		     if (params != null && params.size() > 0) {
		         for (Entry<String, Object> entry : params.entrySet()) {
		             sbParams.append(entry.getKey());  
		             sbParams.append("=");
		             try {
		                 sbParams.append(URLEncoder.encode(String.valueOf(entry.getValue()), charset));  
		             } catch (UnsupportedEncodingException e) {  
		                 throw new RuntimeException(e);  
		             }
		             sbParams.append("&");  
		         }  
		     }
		     if (sbParams != null && sbParams.length() > 0) {
		         urlParam = urlParam + "?" + sbParams.substring(0, sbParams.length() - 1);
		     }
		    /* HttpGet httpGet = new HttpGet(urlParam);
		     RequestConfig requestConfig = RequestConfig.custom()
		             .setConnectTimeout(50000).setConnectionRequestTimeout(10000)
		             .setSocketTimeout(50000).build();
		     httpGet.setConfig(requestConfig);*/
		     
		     CloseableHttpClient httpclient = HttpClients.createDefault();
		     String resp = null;
		     try {
		         // 创建httpget.
		         //HttpGet httpget = new HttpGet("http://117.131.17.78:8080/sales/pricing?clientId=15d13842-f4a8-4b7c-8b30-221ec2f2a074");
		     	HttpGet httpget = new HttpGet(urlParam);
		     	httpget.setHeader("Content-Type","application/json;charset=utf-8");
		         System.out.println("executing request " + httpget.getURI());  
		         // 执行get请求.    
		         CloseableHttpResponse response = httpclient.execute(httpget);
		         response.setHeader("Content-Type","application/json;charset=utf-8");
		         try {
		             // 获取响应实体    
		             HttpEntity entity = response.getEntity();  
		             System.out.println("--------------------------------------");  
		             // 打印响应状态
		             System.out.println(response.getStatusLine());  
		             if (entity != null) {
		                 // 打印响应内容长度    
		                 System.out.println("Response content length: " + entity.getContentLength());  
		                 // 打印响应内容
		                 resp = EntityUtils.toString(entity);
		                 System.out.println("Response content: " + resp);
		             }
		             System.out.println("------------------------------------");  
		         } finally {
		             response.close();  
		            // System.out.println(resp.toString());
		             return resp.toString();
		         }
		     } catch (Exception e) {
		    	 //执行 重复请求
		    	 final Logger logger = Logger.getLogger(HttpRequest.class);
		    	 logger.info("重复请求:当前线程id:"+Thread.currentThread().getId()+";time:"+new Date()+";url:"+urlParam);
		    	 System.out.println(logger);
		    	 System.out.println("重复请求:当前线程id:"+Thread.currentThread().getId()+";time:"+new Date());
		    	 if(null == period || period == 0){
		    		 period = 3000l;
		    	 }
		    	 period = period*2;
		    	 if(period > 200000l){
		    	 }else{
		    		 timeCircle(period, urlParam, params, charset);
		    	 }
		         //throw new RuntimeException(e);  
		     } finally {
		         if (br != null) {
		             try {
		                 br.close();  
		             } catch (IOException e) {  
		                 br = null;  
		                 throw new RuntimeException(e);  
		             }
		         }
		     }
		     if(null == resultBuffer){
		    	 return null;
		     }
		     System.out.println(resp.toString());
		     return resp.toString();
		 }
		 
		 public static void timeCircle(Long period,String urlParam, Map<String, Object> params, String charset){
			 final String urlParamF = urlParam;
			 final Map paramsF = params;
			 final String charsetF = charset;
			 final Long periodF = period;
			 Logger log = Logger.getLogger(HttpRequest.class);
			 log.info("间歇请求:"+urlParam+"；当前延时:"+periodF+"毫秒");
			 TimerTask task = new TimerTask() {
			      @Override
			      public void run() {
			    	  new HttpRequest().httpClientGet(urlParamF, paramsF, charsetF,periodF);
			      }
			    };
			Timer timer = new Timer();
			timer.schedule(task, period);	//延后秒上报
		 }
		 
		 public static String getRealIp(HttpServletRequest request){
			 String ip = null;

			    //X-Forwarded-For：Squid 服务代理
			    String ipAddresses = request.getHeader("X-Forwarded-For");

			    if (ipAddresses == null || ipAddresses.length() == 0 || "unknown".equalsIgnoreCase(ipAddresses)) {
			        //X-Real-IP：nginx服务代理
			        ipAddresses = request.getHeader("X-Real-IP");
			    }
			    if (ipAddresses == null || ipAddresses.length() == 0 || "unknown".equalsIgnoreCase(ipAddresses)) {
			        //Proxy-Client-IP：apache 服务代理
			        ipAddresses = request.getHeader("Proxy-Client-IP");
			    }

			    if (ipAddresses == null || ipAddresses.length() == 0 || "unknown".equalsIgnoreCase(ipAddresses)) {
			        //WL-Proxy-Client-IP：weblogic 服务代理
			        ipAddresses = request.getHeader("WL-Proxy-Client-IP");
			    }

			    if (ipAddresses == null || ipAddresses.length() == 0 || "unknown".equalsIgnoreCase(ipAddresses)) {
			        //HTTP_CLIENT_IP：有些代理服务器
			        ipAddresses = request.getHeader("HTTP_CLIENT_IP");
			    }

			    //有些网络通过多层代理，那么获取到的ip就会有多个，一般都是通过逗号（,）分割开来，并且第一个ip为客户端的真实IP
			    if (ipAddresses != null && ipAddresses.length() != 0) {
			        ip = ipAddresses.split(",")[0];
			    }

			    //还是不能获取到，最后再通过request.getRemoteAddr();获取
			    if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ipAddresses)) {
			        ip = request.getRemoteAddr();
			    }
			    
			    return ip;
		}
		 
		 /*
	     * @description 异常上报
	     * @param 自定义参数
		 * 
		 * @param module
		 *            服务模块
		 * @param ipport
		 * @param exception
		 *            异常信息
		 * @param time
		 *            上报时间
		 * @param extra
		 *            自定义信息
		 * @param priority
		 *            异常级别 0：低 1:中 2 高
		 */
	    public static void report_abnormity(Map<String,String> paramMap){
	    	if(null == paramMap){
	    		return;
	    	}
	    	InetAddress inet;
			try {
				inet = InetAddress.getLocalHost();
				paramMap.put("ipport", inet.getHostAddress());
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd  HH:mm:ss");
			String time = sdf.format(new Date());
			paramMap.put("time", time);
	    	/*paramMap = new HashMap<String,String>();
	    	paramMap.put("module", "facebac-yun-api-nvr v1.81");
	    	paramMap.put("ipport", "119.147.152.10:8301");
	    	paramMap.put("ExceptionInformation", "无法连接数据库");
	    	paramMap.put("time", "2018-12-19 07:00:00");
	    	paramMap.put("extra", "cus");
	    	paramMap.put("priority", "1");*/
	    	JSONObject json = new JSONObject();
	    	for (Map.Entry<String, String> entry : paramMap.entrySet()) {
	    		json.put( entry.getKey(), entry.getValue());
	    	}
	    	Properties properties = new Properties();
	    	String url = properties.getProperty(
					"resources/system.properties", "report.abnormity.url");
	    	//String url = "http://10.10.212.249:8080/api/operations/exception/collectSave.do";
	    			
	    	if(StringUtils.isBlank(url)){
	    		return;
	    	}
	    	String res = postMethod(url, json.toString(),"utf-8",10);
	    	if(StringUtils.isBlank(res)){
	    		LogUtils.info("异常上报接口异常");
	    	}
	    }
	    
	    /**
		 * 
		 * @param module
		 *            服务模块
		 * @param ipport
		 * @param exception
		 *            异常信息
		 * @param time
		 *            上报时间
		 * @param extra
		 *            自定义信息
		 * @param priority
		 *            异常级别 0：低 1:中 2 高
		 */
		public static void report_abnormity(String exception, String extra, Integer priority) {
			try {
		    	InetAddress inet;
		    	JSONObject json1 = new JSONObject();
				try {
					inet = InetAddress.getLocalHost();
					json1.put("ipport", inet.getHostAddress() + ":"+ (port > 0?port:"80**"));
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					json1.put("ipport", "ip:"+ (port > 0?port:"80**"));
				}
				json1.put("module", "facebac_api_stream_auth");
				json1.put("ExceptionInformation", exception);
				String now = CalendarUtils.getJinTianT();
				json1.put("time", now);
				json1.put("extra", extra);
				json1.put("priority", priority);
				if(StringUtils.isBlank(url)){
		    		return;
		    	}
		    	String res = postMethod(url, json1.toString(),"utf-8",10);
				LogUtils.info("=====发送上报数据信息返回数据==" + res);
			} catch (Exception e) {
				LogUtils.info("上报接口异常");
			}

		}
	    
	    public static String postMethod(String urlParam,String body,String charset,int per){
			String res_order=null;
			try {
				org.apache.commons.httpclient.HttpClient httpclient = new org.apache.commons.httpclient.HttpClient();
				PostMethod post = new PostMethod(urlParam);
				post.setRequestHeader("Content-Type","application/json;charset="+charset);
				post.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, charset);
				post.setRequestBody(body);
				httpclient.setConnectionTimeout(per*500);
				httpclient.setTimeout(per*500);
				httpclient.executeMethod(post);
				res_order = new String(post.getResponseBody(), charset);
			} catch (Exception e) {
				e.printStackTrace();
				LogUtils.info("上报接口异常");
			}
			return res_order;
		}
	
	/*
	 * 异常上报前的验证
	 * 控制同类别异常上报频率
	 * tm 上报间隔
	 * application 全局上下文对象
	 * @return false:不需再上报      true 可继续上报
	 */
	public static boolean checkRep(String key,int tm,ServletContext application){
		if(tm > 0 && StringUtils.isNotBlank(key) && null != application){
			if(null != application.getAttribute(key)){
				Long timeOld = Long.valueOf(application.getAttribute(key).toString());
				if((System.currentTimeMillis() - timeOld)/1000 < tm ){	//时限内
					return false;
				}
			}
			application.setAttribute(key, System.currentTimeMillis());
			return true;
		}
		return false;
	}
	    
	    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//report_abnormity(new HashMap<String,String>());
		String phone = "18620322843";
		String message="测试短信，123456";
		String type="COLD_VBETY_PRODUCTION";
		System.out.println(MwCloud_SMS_Send.sendSMInfo (phone,message,type));
	}
}
