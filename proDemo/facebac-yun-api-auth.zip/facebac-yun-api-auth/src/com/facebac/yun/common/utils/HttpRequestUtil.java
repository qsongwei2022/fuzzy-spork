package com.facebac.yun.common.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;


public class HttpRequestUtil {
	
	/**
	 * 向指定 URL 发送POST方法的请求
	 * 
	 * @param url
	 *            发送请求的 URL
	 * @param param
	 *            请求参数，请求参数应该是 Json 的形式。
	 * @return 所代表远程资源的响应结果
	 * @throws IOException 
	 */
	public static String sendPostJson(String url, String param) throws IOException,ConnectException,SocketTimeoutException {
		BufferedReader in = null;
		String result = "";
		URL realUrl = new URL(url);
		// 打开和URL之间的连接
		URLConnection conn = realUrl.openConnection();
		//请求超时
		conn.setConnectTimeout(5000);
		//响应超时
		conn.setReadTimeout(5000);
		// 设置通用的请求属性
		conn.setRequestProperty("Content-Type", "application/json");
		//conn.setRequestProperty("accept", "*/*");
		//conn.setRequestProperty("connection", "Keep-Alive");
		//conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
		// 发送POST请求必须设置如下两行
		conn.setDoOutput(true);
		conn.setDoInput(true);
		System.out.println(conn.getURL());
		// 获取URLConnection对象对应的输出流
		OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());  
        //发送参数  
        writer.write(param);
		// flush输出流的缓冲
        writer.flush();
		// 定义BufferedReader输入流来读取URL的响应
		in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		String line;
		while ((line = in.readLine()) != null) {
			result += line;
		}
		if (writer != null) {
			writer.close();
		}
		if (in != null) {
			in.close();
		}
		return result;
	}
	

	 /**
	  * 向指定URL发送GET方法的请求
	  * 
	  * @param url
	  *            发送请求的URL
	  * @param param
	  *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
	  *        headersMap 设置头信息     
	  * @return URL 所代表远程资源的响应结果
	  */
	 public static String sendGet(String url, String param,Map<String,String> headersParamMap) {
	     String result = "";
	     BufferedReader in = null;
	     try {
	         String urlNameString = null;
	         
	         if (param==null || "".equals(param.trim())){
	        	 urlNameString = url;
	         }else{
	        	 urlNameString = url + "?" + param;
	         }
	         //LogUtils.info(" === http get url : "+urlNameString);
	         
	         URL realUrl = new URL(urlNameString);
	         // 打开和URL之间的连接  
	         // HttpURLConnection 可以得到状态
	         URLConnection connection = realUrl.openConnection();
	         // 设置通用的请求属性
	         connection.setRequestProperty("accept", "*/*");
	         connection.setRequestProperty("connection", "Keep-Alive");
	         //connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
	         connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0");  
	         if (headersParamMap!=null && headersParamMap.size()>0){
	        	 for(Map.Entry<String, String> entry:headersParamMap.entrySet()){
	        		 connection.setRequestProperty(entry.getKey(), entry.getValue());
	        	 }
	         }
	         
	         //打印请求头
	         /* Map<String,List<String>> requestMap =  connection.getRequestProperties();
	         //System.out.println("=====================>>请求头");
	         for (String key : requestMap.keySet()) {
	             //System.out.println(key + ">>" + requestMap.get(key));
	         }         */
	         
	         // 建立实际的连接
	         connection.connect();
	         // 获取所有响应头字段
	         
	         /*Map<String, List<String>> map = connection.getHeaderFields();
	         // 遍历所有的响应头字段
	         //System.out.println("=====================>>响应头 ");
	         for (String key : map.keySet()) {
	             //System.out.println(key + "<< " + map.get(key));
	         }*/
	         // 定义 BufferedReader输入流来读取URL的响应
	         in = new BufferedReader(new InputStreamReader(
	                 connection.getInputStream()));
	         String line;
	         while ((line = in.readLine()) != null) {
	             result += line;
	         }
	     } catch (Exception e) {
	         System.out.println("发送GET请求出现异常！" + e);
	         e.printStackTrace();
	     }
	     // 使用finally块来关闭输入流
	     finally {
	         try {
	             if (in != null) {
	                 in.close();
	             }
	         } catch (Exception e2) {
	             e2.printStackTrace();
	         }
	     }
	     return result;
	 }
	 
	 	/** 
	     * 向指定 URL 发送POST方法的请求 
	     *  
	     * @param url 
	     *            发送请求的 URL 
	     * @param param 
	     *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。 
	     * @return 所代表远程资源的响应结果 
	     */  
	    public static String sendPost(String url, String param) {  
	        OutputStreamWriter out = null;  
	        BufferedReader in = null;  
	        String result = "";  
	        try {  
	              
	            URL realUrl = new URL(url);  
	            // 打开和URL之间的连接  
	            URLConnection conn = realUrl.openConnection();  
	            // 设置通用的请求属性  
	            conn.setRequestProperty("accept", "*/*");  
	            conn.setRequestProperty("connection", "Keep-Alive");  
	            conn.setRequestProperty("user-agent",  
	                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");  
	              
	            conn.setRequestProperty("charsert", "gbk");  
	            // 发送POST请求必须设置如下两行  
	            conn.setDoOutput(true);  
	            conn.setDoInput(true); 
	            // 获取URLConnection对象对应的输出流  
	            System.out.println(conn.getURL());
	            out = new OutputStreamWriter(conn.getOutputStream(),"utf8");//如果参数有中文，这里最好设置下编码，要不会出现乱码  
	            // 发送请求参数  
	            out.write(param);  
	            // flush输出流的缓冲  
	            out.flush();  
	            // 定义BufferedReader输入流来读取URL的响应  
	            
	            in = new BufferedReader(  
	                    new InputStreamReader(conn.getInputStream(), "utf-8"));
	            String line;  
	            while ((line = in.readLine()) != null) {  
	                result += line;  
	            }  
	        } catch (Exception e) {  
	            System.out.println("发送 POST 请求出现异常！"+e);  
	            e.printStackTrace();   
	        }  
	        //使用finally块来关闭输出流、输入流  
	        finally{  
	            try{  
	                if(out!=null){  
	                    out.close();  
	                }  
	                if(in!=null){  
	                    in.close();  
	                }  
	            }  
	            catch(IOException ex){  
	                ex.printStackTrace();  
	            }  
	        }  
	        return result;  
	    } 
	    public static String createServer(String url, String param) throws IOException,ConnectException,SocketTimeoutException {
			BufferedReader in = null;
			String result = "";
			URL realUrl = new URL(url);
			// 打开和URL之间的连接
			HttpURLConnection conn  = (HttpURLConnection)realUrl.openConnection();
			//请求超时
			conn.setConnectTimeout(15000);
			//响应超时
			conn.setReadTimeout(15000);
			// 设置通用的请求属性
			String time = new Date().getTime()+"";
			String cnonce = (int)((Math.random()*9+1)*10000)+"";
			System.out.println(time);
			System.out.println(cnonce);
			System.out.println(HMAC_SHA1.genHMAC(time+","+cnonce, 21890+""));
			System.out.println(HMAC_SHA1.encode(HMAC_SHA1.genHMAC(time+","+cnonce, 21890+"")));
			conn.setRequestProperty("Authorization", "MAuth realm=http://marte3.dit.upm.es,mauth_signature_method=HMAC_SHA1,mauth_serviceid=5c91ae4086f6c0d150def819,mauth_cnonce="+cnonce+",mauth_timestamp="+time+",mauth_signature="+HMAC_SHA1.encode(HMAC_SHA1.genHMAC(time+","+cnonce, 21890+"")));
			conn.setRequestProperty("Content-Type", "application/json");
			
			
			/*conn.setRequestProperty("MAuth realm", "http://marte3.dit.upm.es");
			conn.setRequestProperty("mauth_signature_method", "HMAC_SHA1");
			conn.setRequestProperty("mauth_serviceid", "5ca1b5c58d26e5f60865ec78");
			conn.setRequestProperty("mauth_cnonce", "46404");
			String timestamp = new Date().getTime()+"";
			conn.setRequestProperty("mauth_timestamp", "1554107340218");
			conn.setRequestProperty("mauth_signature", "N2JmOTMxMzBlN2RlMWE0YmUyZDhkZTlhMjBhZTMwOTNkYmIyYTIzNg==");*/
			//conn.setRequestProperty("accept", "*/*");
			//conn.setRequestProperty("connection", "Keep-Alive");
			//conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			// 获取URLConnection对象对应的输出流
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());  
	        //发送参数  
	        writer.write(param);
			// flush输出流的缓冲
	        writer.flush();
			// 定义BufferedReader输入流来读取URL的响应
	        if(conn.getResponseCode()==200){
	        	in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	        }else{
	        	in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
	        }
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}
			if (writer != null) {
				writer.close();
			}
			if (in != null) {
				in.close();
			}
			return result;
		}
	    
	    
	    /**
		  * 向指定URL发送GET方法的请求
		  * 
		  * @param url
		  *            发送请求的URL
		  * @param param
		  *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
		  *        headersMap 设置头信息     
		  * @return URL 所代表远程资源的响应结果
		  */
		 public static String getServer(String url, String param,Map<String,String> headersParamMap) {
		     String result = "";
		     BufferedReader in = null;
		     try {
		         String urlNameString = null;
		         
		         if (param==null || "".equals(param.trim())){
		        	 urlNameString = url;
		         }else{
		        	 urlNameString = url + "?" + param;
		         }
		         //LogUtils.info(" === http get url : "+urlNameString);
		         
		         URL realUrl = new URL(urlNameString);
		         // 打开和URL之间的连接  
		         // HttpURLConnection 可以得到状态
		         URLConnection connection = realUrl.openConnection();
		         // 设置通用的请求属性
		         connection.setRequestProperty("accept", "*/*");
		         connection.setRequestProperty("connection", "Keep-Alive");
		         //connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
		         connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0");  
		         String time = new Date().getTime()+"";
					String cnonce = (int)((Math.random()*9+1)*10000)+"";
					System.out.println(time);
					System.out.println(cnonce);
					System.out.println(HMAC_SHA1.genHMAC(time+","+cnonce, 21890+""));
					System.out.println(HMAC_SHA1.encode(HMAC_SHA1.genHMAC(time+","+cnonce, 21890+"")));
					connection.setRequestProperty("Authorization", "MAuth realm=http://marte3.dit.upm.es,mauth_signature_method=HMAC_SHA1,mauth_serviceid=5c91ae4086f6c0d150def819,mauth_cnonce="+cnonce+",mauth_timestamp="+time+",mauth_signature="+HMAC_SHA1.encode(HMAC_SHA1.genHMAC(time+","+cnonce, 21890+"")));
					//connection.setRequestProperty("Content-Type", "application/json");

		         if (headersParamMap!=null && headersParamMap.size()>0){
		        	 for(Map.Entry<String, String> entry:headersParamMap.entrySet()){
		        		 connection.setRequestProperty(entry.getKey(), entry.getValue());
		        	 }
		         }
		         
		         //打印请求头
		         /* Map<String,List<String>> requestMap =  connection.getRequestProperties();
		         //System.out.println("=====================>>请求头");
		         for (String key : requestMap.keySet()) {
		             //System.out.println(key + ">>" + requestMap.get(key));
		         }         */
		         
		         // 建立实际的连接
		         connection.connect();
		         // 获取所有响应头字段
		         
		         /*Map<String, List<String>> map = connection.getHeaderFields();
		         // 遍历所有的响应头字段
		         //System.out.println("=====================>>响应头 ");
		         for (String key : map.keySet()) {
		             //System.out.println(key + "<< " + map.get(key));
		         }*/
		         // 定义 BufferedReader输入流来读取URL的响应
		         in = new BufferedReader(new InputStreamReader(
		                 connection.getInputStream()));
		         String line;
		         while ((line = in.readLine()) != null) {
		             result += line;
		         }
		     } catch (Exception e) {
		         System.out.println("发送GET请求出现异常！" + e);
		         e.printStackTrace();
		     }
		     // 使用finally块来关闭输入流
		     finally {
		         try {
		             if (in != null) {
		                 in.close();
		             }
		         } catch (Exception e2) {
		             e2.printStackTrace();
		         }
		     }
		     return result;
		 }
		 
		 
		 public static String createToken(String url, String param) throws IOException,ConnectException,SocketTimeoutException {
				BufferedReader in = null;
				String result = "";
				URL realUrl = new URL(url);
				// 打开和URL之间的连接
				HttpURLConnection conn  = (HttpURLConnection)realUrl.openConnection();
				//请求超时
				conn.setConnectTimeout(15000);
				//响应超时
				conn.setReadTimeout(15000);
				// 设置通用的请求属性
				String time = new Date().getTime()+"";
				String cnonce = (int)((Math.random()*9+1)*10000)+"";
				System.out.println(time);
				System.out.println(cnonce);
				System.out.println(HMAC_SHA1.genHMAC(time+","+cnonce+","+"123"+","+"role1", 21890+""));
				System.out.println(HMAC_SHA1.encode(HMAC_SHA1.genHMAC(time+","+cnonce+","+"123"+","+"role1", 21890+"")));
				String head = "MAuth realm=http://marte3.dit.upm.es," + 
						"mauth_signature_method=HMAC_SHA1," + 
						"mauth_username=123," + 
						"mauth_role=role1," + 
						"mauth_serviceid=5c91ae4086f6c0d150def819," + 
						"mauth_cnonce=" + cnonce+","+
						"mauth_timestamp=" +time+","+ 
						"mauth_signature="+HMAC_SHA1.encode(HMAC_SHA1.genHMAC(time+","+cnonce+","+"123"+","+"role1", 21890+""));
				System.out.println(head);
				conn.setRequestProperty("Authorization", head);
				conn.setRequestProperty("Content-Type", "application/json");
				
				/*conn.setRequestProperty("MAuth realm", "http://marte3.dit.upm.es");
				conn.setRequestProperty("mauth_signature_method", "HMAC_SHA1");
				conn.setRequestProperty("mauth_serviceid", "5ca1b5c58d26e5f60865ec78");
				conn.setRequestProperty("mauth_cnonce", "46404");
				String timestamp = new Date().getTime()+"";
				conn.setRequestProperty("mauth_timestamp", "1554107340218");
				conn.setRequestProperty("mauth_signature", "N2JmOTMxMzBlN2RlMWE0YmUyZDhkZTlhMjBhZTMwOTNkYmIyYTIzNg==");*/
				//conn.setRequestProperty("accept", "*/*");
				//conn.setRequestProperty("connection", "Keep-Alive");
				//conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
				// 发送POST请求必须设置如下两行
				conn.setDoOutput(true);
				conn.setDoInput(true);
				// 获取URLConnection对象对应的输出流
				OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());  
		        //发送参数  
		        writer.write(param);
				// flush输出流的缓冲
		        writer.flush();
				// 定义BufferedReader输入流来读取URL的响应
		        in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String line;
				while ((line = in.readLine()) != null) {
					result += line;
				}
				if (writer != null) {
					writer.close();
				}
				if (in != null) {
					in.close();
				}
				return result;
			}
		 
		 /** 
		  * 发送 get请求 
		  */  
		 public static String httpGet(String url,int per) {
		     CloseableHttpClient httpclient = HttpClients.createDefault();
		     if(per <= 0){
		    	 per = 10;
		     }
		     String resp = null;
		     try {
		         // 创建httpget.
		     	HttpGet httpget = new HttpGet(url);
		     	String time = new Date().getTime()+"";
				String cnonce = (int)((Math.random()*9+1)*10000)+"";
		     	String head = "MAuth realm=http://marte3.dit.upm.es," + 
						"mauth_signature_method=HMAC_SHA1," + 
						"mauth_username=123," + 
						"mauth_role=role1," + 
						"mauth_serviceid=5c91ae4086f6c0d150def819," + 
						"mauth_cnonce=" + cnonce+","+
						"mauth_timestamp=" +time+","+ 
						"mauth_signature="+HMAC_SHA1.encode(HMAC_SHA1.genHMAC(time+","+cnonce+","+"123"+","+"role1", 21890+""));
				System.out.println(head);
				httpget.setHeader("Content-Type","application/json;charset=utf-8");
				httpget.setHeader("Authorization", head);
		         System.out.println("executing request " + httpget.getURI());  
		         // 执行get请求.    
		         CloseableHttpResponse response = httpclient.execute(httpget);
		         response.setHeader("Content-Type","application/json;charset=utf-8");
		         try {
		             // 获取响应实体    
		             HttpEntity entity = response.getEntity();  
		             System.out.println("--------------------------------------");  
		             // 打印响应状态
		             System.out.println(response.getStatusLine());  
		             if (entity != null) {
		                 // 打印响应内容长度    
		                 System.out.println("Response content length: " + entity.getContentLength());  
		                 // 打印响应内容
		                 resp = EntityUtils.toString(entity);
		                 System.out.println("Response content: " + resp);
		             }
		             System.out.println("------------------------------------");  
		         } finally {
		             response.close();  
		         }
		     } catch (ClientProtocolException e) {
		         e.printStackTrace();  
		     } catch (IOException e) {  
		         e.printStackTrace();  
		     } finally {  
		         // 关闭连接,释放资源    
		         try {
		             httpclient.close();  
		         } catch (IOException e) {  
		             e.printStackTrace();  
		         }
		     }
		     return resp;
		 }
		 
		 public static String doPost(String url, String params){

	  			CloseableHttpClient httpclient = HttpClients.createDefault();
	  			HttpPost httpPost = new HttpPost(url);// 创建httpPost
	  			httpPost.setHeader("Accept", "application/json");
	  			String time = new Date().getTime()+"";
				String cnonce = (int)((Math.random()*9+1)*10000)+"";
		     	String head = "MAuth realm=http://marte3.dit.upm.es," + 
						"mauth_signature_method=HMAC_SHA1," + 
						"mauth_username=123," + 
						"mauth_role=role1," + 
						"mauth_serviceid=5c91ae4086f6c0d150def819," + 
						"mauth_cnonce=" + cnonce+","+
						"mauth_timestamp=" +time+","+ 
						"mauth_signature="+HMAC_SHA1.encode(HMAC_SHA1.genHMAC(time+","+cnonce+","+"123"+","+"role1", 21890+""));
				httpPost.setHeader("Content-Type","application/json;charset=utf-8");
				httpPost.setHeader("Authorization", head);
	  			
	  			String charSet = "UTF-8";
	  			StringEntity entity = new StringEntity(params, charSet);
	  			httpPost.setEntity(entity);
	  			CloseableHttpResponse response = null;

	  			try {
	  				response = httpclient.execute(httpPost);
	  				StatusLine status = response.getStatusLine();
	  				int state = status.getStatusCode();
	  				if (state == HttpStatus.SC_OK) {
	  					HttpEntity responseEntity = response.getEntity();
	  					String jsonString = EntityUtils.toString(responseEntity);
	  					return jsonString;
	  				} else {
	  					System.out.println(state);
	  					//logger.error("请求返回:" + state + "(" + url + ")");
	  				}
	  			} 
	  			catch (Exception e) {
	  				e.printStackTrace();
	  			}finally {
	  				if (response != null) {
	  					try {
	  						response.close();
	  					} catch (IOException e) {
	  						e.printStackTrace();
	  					}
	  				}
	  				try {
	  					httpclient.close();
	  				} catch (IOException e) {
	  					e.printStackTrace();
	  				}
	  			}
	  			return null;
	  		}
		 
	    public static void main(String[] args) {
	    	try {
	    		//String str=createServer("http://218.25.208.124:3000/services/", "{\"name\": \"newserice11\", \"key\": \"21833\"}");
				//String str = "\"5cac6a8bbc64bb06a8f6ffed\"";
	    		String str = "\"5cad4070be617456a38eddd4\"";
	    		/*System.out.println(str);
				System.out.println(str.substring(1, str.length()-1));
				String vr=getServer("http://218.25.208.124:3000/services/"+str.substring(1, str.length()-1), "",null);
				System.out.println(vr);
				String getroom = getServer("http://218.25.208.124:3000/rooms/", "",null);
				System.out.println(getroom);*/
				//String croom=createServer("http://218.25.208.124:3000/rooms/", "{\"service\": \""+str.substring(1, str.length()-1)+"\", \"name\": \"wgy\"}");
				//System.out.println(croom);
				String ctoken = createServer("http://218.25.208.124:3000/rooms/5cac69019bc64bb06a8f6ffe9/tokens","");
				
				System.out.println(ctoken);
				
	    	} catch (Exception e) {
				e.printStackTrace();
			} 
		}
}
