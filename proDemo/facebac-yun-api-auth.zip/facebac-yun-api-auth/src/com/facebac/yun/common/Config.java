package com.facebac.yun.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Config {
	@Value("${facebac.api.lCoUrl}")
	private String lCoUrl;
	
	@Value("${facebac.api.limicount}")
	private Integer limicount;
	
	@Value("${facebac.api.antiLeechTime}")
	private String antiLeechTime;
	
	@Value("${report.abnormity.url}")
	private String report_url;
	
	public String getlCoUrl() {
		return lCoUrl;
	}

	public void setlCoUrl(String lCoUrl) {
		this.lCoUrl = lCoUrl;
	}

	public Integer getLimicount() {
		return limicount;
	}

	public void setLimicount(Integer limicount) {
		this.limicount = limicount;
	}

	public String getAntiLeechTime() {
		return antiLeechTime;
	}

	public void setAntiLeechTime(String antiLeechTime) {
		this.antiLeechTime = antiLeechTime;
	}

	public String getReport_url() {
		return report_url;
	}

	public void setReport_url(String report_url) {
		this.report_url = report_url;
	}
	
}
