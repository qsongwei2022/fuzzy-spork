package com.facebac.yun.model.json;

import java.util.List;

/**
 * @author  leihua
 * @date [2016年4月14日 上午10:47:00]
 * @version   1.0
 */
public class JsonNotifyM3u8Data {
    private String id;

    private Integer code;

    private String inputkey;

    private String inputbucket;

    private Long inputfsize;

    private String desc;

    private Integer separate;
    
    private List<JsonNotifyM3u8DataItems> items;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getInputkey() {
		return inputkey;
	}

	public void setInputkey(String inputkey) {
		this.inputkey = inputkey;
	}

	public String getInputbucket() {
		return inputbucket;
	}

	public void setInputbucket(String inputbucket) {
		this.inputbucket = inputbucket;
	}

	public Long getInputfsize() {
		return inputfsize;
	}

	public void setInputfsize(Long inputfsize) {
		this.inputfsize = inputfsize;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Integer getSeparate() {
		return separate;
	}

	public void setSeparate(Integer separate) {
		this.separate = separate;
	}

	public List<JsonNotifyM3u8DataItems> getItems() {
		return items;
	}

	public void setItems(List<JsonNotifyM3u8DataItems> items) {
		this.items = items;
	}
    
}
