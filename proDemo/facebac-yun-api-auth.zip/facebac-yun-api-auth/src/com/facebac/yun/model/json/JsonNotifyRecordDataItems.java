package com.facebac.yun.model.json;

import java.math.BigDecimal;

/**
 * @author  leihua
 * @date [2016年4月21日 下午2:11:52]
 * @version   1.0
 */
public class JsonNotifyRecordDataItems {
	
	private String stream_id;
	
	private String begin_time;
	
	private String end_time;
	
	private String file_path;
	
	private String resolution;
	
	private BigDecimal duration;
	
	private Long size;
	
	private Integer fps;
	
	private Integer vcodec;
	
	private Integer acodec;
	
	private Long kbps;
	
	private Long rcv_bytes;
	
	public String getStream_id() {
		return stream_id;
	}

	public void setStream_id(String stream_id) {
		this.stream_id = stream_id;
	}

	public String getBegin_time() {
		return begin_time;
	}

	public void setBegin_time(String begin_time) {
		this.begin_time = begin_time;
	}

	public String getEnd_time() {
		return end_time;
	}

	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

	public String getFile_path() {
		return file_path;
	}

	public void setFile_path(String file_path) {
		this.file_path = file_path;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public BigDecimal getDuration() {
		return duration;
	}

	public void setDuration(BigDecimal duration) {
		this.duration = duration;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public Integer getFps() {
		return fps;
	}

	public void setFps(Integer fps) {
		this.fps = fps;
	}

	public Integer getVcodec() {
		return vcodec;
	}

	public void setVcodec(Integer vcodec) {
		this.vcodec = vcodec;
	}

	public Integer getAcodec() {
		return acodec;
	}

	public void setAcodec(Integer acodec) {
		this.acodec = acodec;
	}

	public Long getKbps() {
		return kbps;
	}

	public void setKbps(Long kbps) {
		this.kbps = kbps;
	}

	public Long getRcv_bytes() {
		return rcv_bytes;
	}

	public void setRcv_bytes(Long rcv_bytes) {
		this.rcv_bytes = rcv_bytes;
	}
	
}
