package com.facebac.yun.model.json;

import java.util.List;

/**
 * @author : leihua 
 * @date : 2017年2月7日 下午2:14:22
 * @version : 
 * @describe : 
 */
public class JsonNotifyRecordMergeData {
	
	private String rec_type;
	
	private String cmd_id;
	
	private String ip;
	
	private List<JsonNotifyRecordDataItems> items;

	public String getRec_type() {
		return rec_type;
	}

	public void setRec_type(String rec_type) {
		this.rec_type = rec_type;
	}
	
	public String getCmd_id() {
		return cmd_id;
	}

	public void setCmd_id(String cmd_id) {
		this.cmd_id = cmd_id;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public List<JsonNotifyRecordDataItems> getItems() {
		return items;
	}

	public void setItems(List<JsonNotifyRecordDataItems> items) {
		this.items = items;
	}
}
