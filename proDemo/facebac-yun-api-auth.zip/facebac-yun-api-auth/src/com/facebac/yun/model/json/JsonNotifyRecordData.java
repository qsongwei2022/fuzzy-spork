package com.facebac.yun.model.json;

import java.util.List;

/**
 * @author  leihua
 * @date [2016年4月21日 下午2:11:31]
 * @version   1.0
 */
public class JsonNotifyRecordData {
	private String rec_type;
	
	private String ip;
	
	private List<JsonNotifyRecordDataItems> items;

	public String getRec_type() {
		return rec_type;
	}

	public void setRec_type(String rec_type) {
		this.rec_type = rec_type;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public List<JsonNotifyRecordDataItems> getItems() {
		return items;
	}

	public void setItems(List<JsonNotifyRecordDataItems> items) {
		this.items = items;
	}
	
	
}
