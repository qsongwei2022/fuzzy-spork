package com.facebac.yun.model.vo;

import java.util.Date;

/**
 * 防盗链临时公共类 
 */
public class CommonAuV {
	private String id;
	private String push_code;
	private Date start_against;
	private Date end_against;
	private Date beginTime;
	private Date endTime;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPush_code() {
		return push_code;
	}
	public void setPush_code(String push_code) {
		this.push_code = push_code;
	}
	public Date getStart_against() {
		return start_against;
	}
	public void setStart_against(Date start_against) {
		this.start_against = start_against;
	}
	public Date getEnd_against() {
		return end_against;
	}
	public void setEnd_against(Date end_against) {
		this.end_against = end_against;
	}
	public Date getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
}
