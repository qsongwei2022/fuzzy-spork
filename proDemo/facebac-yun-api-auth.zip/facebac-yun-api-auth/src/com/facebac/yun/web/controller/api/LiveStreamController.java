package com.facebac.yun.web.controller.api;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.facebac.yun.common.utils.Commonutils;
import com.facebac.yun.common.utils.Constants;
import com.facebac.yun.common.utils.LogUtils;
import com.facebac.yun.common.utils.MD5Utils;
import com.facebac.yun.common.utils.Report;
import com.facebac.yun.common.utils.ThreadManagerUtil;
import com.facebac.yun.console.redis.RedisDBService;
import com.facebac.yun.model.api.ParamStream;
import com.facebac.yun.model.api.ResultCode;
import com.facebac.yun.model.api.ResultCodeDataStr;
import com.facebac.yun.service.business.api.ILiveStreamService;

/**
 * 直播流接口
 * 主要用于对外。 如:网宿 \ app 等
 * @author  leihua
 * @date [2016年3月18日 下午6:08:27]
 * @version   1.0
 */

@Controller  
@RequestMapping("/api/stream") 
public class LiveStreamController {

	@Autowired
	private HttpServletRequest request;
	
	@Resource(name = "liveStreamServiceImpl")
	public ILiveStreamService liveStreamServiceImpl;
	
	@Resource(name = "redisDBService")
	private RedisDBService redisDBService;
	
	private ServletContext application;
	
	public int ocRdisSLog(int slog,ServletContext application){
		try {
			String SLOGTMP = redisDBService.GET("SLOG");
			if(null != SLOGTMP){
				slog = Integer.parseInt(SLOGTMP);
				if(slog == 1){
					Enumeration names = request.getHeaderNames();
					while(names.hasMoreElements()){
			            String name = (String) names.nextElement();
			            LogUtils.info(name + ":" + request.getHeader(name));
			         }
			    	Enumeration req_names = request.getParameterNames();
			    	while(req_names.hasMoreElements()){
			            String name = (String) req_names.nextElement();
			            LogUtils.info(name + ":" + request.getParameter(name));
			         }
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			LogUtils.info("redis中日志标识获取异常");
			if(Commonutils.checkRep(Constants.Code_redis_Con_Exc, 100, application)){
				ThreadManagerUtil.getInstance().execute(new Report("redis connect exception", "liveStreamController.ocRdisSLog", 3));
			}
		}
		return slog;
	}
	
	@ResponseBody
	@RequestMapping(value="/auth/setSlog") 
	public ResultCode setSlog(@RequestParam(value="slog",required=false) String slog){
		if(StringUtils.isNotBlank(slog)){
			redisDBService.SET("SLOG", slog);
			return ResultCodeDataStr.SUCCESS();
		}else{
			return ResultCodeDataStr.ERROR();
		}
	}
	
	/**
	 * 直播播放鉴权
	 * @param paramStream
	 * @return  1:成功  0：失败
	 */
	@ResponseBody
	@RequestMapping(value="/auth/play") 
	public void authPaly(@ModelAttribute("paramStream") ParamStream paramStream,HttpServletResponse response,
			HttpServletRequest  request){
		application = request.getServletContext();
		try {
			int res = commonParamDisposeLp(paramStream);
			if(res == 0){
				LogUtils.info("---play param error---");
				ajaxPrintPage(response, "0");
	        	return ;
			}
			LogUtils.info("--live_play auth--rid:"+paramStream.getChannel());
			int slog = 0;
			slog = ocRdisSLog(slog,application);
			if(slog == 1){
		    	LogUtils.info("---------直播播放鉴全参数end--------");
			}
			//ServletContext application = request.getServletContext();
			//判断必要参数
			if (StringUtils.isBlank(paramStream.getChannel()) ||  StringUtils.isBlank(paramStream.getSecret())){
				LogUtils.info("---play param error---");
				ajaxPrintPage(response, "0");
	        	return ;
			}
			//多码率地址 鉴权时参数处理
			if(paramStream.getChannel().contains("_") && paramStream.getChannel().endsWith("0")){
				String str2 = paramStream.getChannel().split("_")[0];
				if(StringUtils.isNotBlank(str2)){
					paramStream.setChannel(str2);
				}
			}
			String md5Val = MD5Utils.getMD5String(paramStream.getChannel()+"bk");
			if(StringUtils.isNotBlank(paramStream.getSourceType()) && StringUtils.isNotEmpty(paramStream.getSourceType())){
				if(md5Val.equals(paramStream.getSourceType()) || md5Val == paramStream.getSourceType()){
					//运营直通
					ajaxPrintPage(response, "1");
					return;
				}else{
					LogUtils.info("直播鉴全直通签名不匹配，md5Val:"+md5Val+";sourceType:"+paramStream.getSourceType());
				}
			}
			
			if(paramStream.getToken().contains("directauthentication")){
				//直播内部探测直通
				ajaxPrintPage(response, "1");
				return;
			}
			String ip = paramStream.getClientip();
			if(StringUtils.isBlank(ip)){
				ip = paramStream.getIp();
				if(StringUtils.isBlank(ip)){
					ip = Commonutils.getRealIp(request);
					paramStream.setClientip(ip);
				}
			}
			paramStream.setPlaySource("3");
			int resInt = liveStreamServiceImpl.authPaly(paramStream,application);
			if (resInt==0){
				LogUtils.info("live play forbid,liveRid:"+paramStream.getChannel());
				ajaxPrintPage(response, "0");
				return;
			}else{
				//如果配置了鉴权转移功能 则将鉴权移交配置的三方回调处理
				int AuthTrans = 1;
	        	try {
	        		AuthTrans = liveStreamServiceImpl.checkAuthTrans(paramStream,1,application);
	    			if(AuthTrans == 0){
	    				ajaxPrintPage(response, "0");
						return;
	    			}else{
	    				ajaxPrintPage(response, "1");
	    			}
				} catch (Exception e) {
					// TODO: handle exception
					LogUtils.info("-------AuthTrans exception--------");
					ajaxPrintPage(response, "1");
				}
				commonAddPTi(paramStream,"1",request,application);	//鉴权成功  增加播放次数
			}
		} catch (Exception e) {
			// TODO: handle exception
			//上报直播播放异常
			LogUtils.info("live authplay run exception");
		}
	}
	
	/*
	 *  新增优化地址后鉴权处理 2018-12-10 10:15:03 
	 *  直播推流播放兼容url
	 */
	public int commonParamDisposePu(ParamStream paramStream){
		if(paramStream==null || StringUtils.isBlank(paramStream.getToken()) || StringUtils.isBlank(paramStream.getSecret())){
        	return 0;
		}
		String tmp = paramStream.getSecret();
		if(tmp.contains("_")){
			String secret = tmp.split("_")[0];
			String xstToken = tmp.split("_")[1];
			if(StringUtils.isBlank(secret) || StringUtils.isBlank(xstToken)){
	        	return 0;
			}
			paramStream.setSecret(secret);
			paramStream.setXstToken(xstToken);
			paramStream.setPush_code(xstToken);
		}
		return 1;
	}
	
	/*
	 *  新增优化地址后鉴权处理 2018-12-26 20:11:58
	 *  直播播放
	 *  兼容 1.token ： MD5加密_防盗码 2.token为urid，secret：MD5加密_防盗码
	 *  url?token=MD5加密_防盗码  / url?token=urid&secret=MD5加密_防盗码
	 *  url?token=urid&secret=MD5&xstToken=as
	 */
	public int commonParamDisposeLp(ParamStream paramStream){
		if(paramStream == null || StringUtils.isBlank(paramStream.getToken())){
        	return 0;
		}
		String tmp = paramStream.getToken();
		if(paramStream.getToken().contains("_")){
			tmp = paramStream.getToken();
		}else if(StringUtils.isNotBlank(paramStream.getSecret()) && paramStream.getSecret().contains("_")){
			tmp = paramStream.getSecret();
		}
		if(tmp.contains("_")){
			String secret = tmp.split("_")[0];
			String xstToken = tmp.split("_")[1];
			if(StringUtils.isBlank(secret) || StringUtils.isBlank(xstToken)){
				return 0;
			}
			paramStream.setSecret(secret);
			paramStream.setXstToken(xstToken);
		}
		return 1;
	}
	
	
	/**
	 * 直播播放鉴权控流次数查询
	 * @param liveid
	 * @return 
	 * @return  n  n为正整数
	 */
	@ResponseBody
	@RequestMapping(value="/auth/auPlayCount") 
	public ResultCode auPlayCount(@RequestParam(value="liveID",required=false) String liveID){
		if(StringUtils.isBlank(liveID)){
			LogUtils.info("---liveLimitCount param error---");
			return ResultCodeDataStr.ERROR("invalid argument");
		}
		String auPlayCount = liveStreamServiceImpl.auPlayCount(liveID);
		return ResultCodeDataStr.INFO("200", "当前限定时间内设定鉴权次数+当前鉴权实际次数", auPlayCount);
	}
	
	/**
     * 录播鉴权
     * 
     * @param paramStream
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/auth/video_play")
    public void authVideoPlay(@ModelAttribute("paramStream") ParamStream paramStream,HttpServletRequest request,
            HttpServletResponse response) {
    	application = request.getServletContext();
    	LogUtils.info("--video_record auth--rid"+paramStream.getChannel()+"--orgName--"+paramStream.getOrgName());
    	int slog = 0;
		slog = ocRdisSLog(slog,application);
		if(slog == 1){
	    	LogUtils.info("---------录像播放鉴全参数end--------");
		}
		String ip = request.getHeader("cdn-src-ip");
    	if(StringUtils.isBlank(ip)){
    		ip = request.getHeader("x-forwarded-for");
    	}
    	if (paramStream == null || StringUtils.isEmpty(paramStream.getChannel()) || StringUtils.isEmpty(paramStream.getOrgName())) {
    		LogUtils.info("---video_play param error---");
    		ajaxPrintPage(response, "0");
        	return ;
        }
    	paramStream.setClientip(ip);
        paramStream.setPlaySource("3");
		int resInt = liveStreamServiceImpl.authVideo(paramStream,application);
        if (resInt == 0) {
        	//LogUtils.info("录播 鉴权失败 0 ：" + paramStream.getChannel());
        	ajaxPrintPage(response, "0");
        	return ;
        } else {
        	//如果配置了鉴权转移功能 则将鉴权移交配置的三方回调处理
        	int AuthTrans = 1;
        	try {
        		AuthTrans = liveStreamServiceImpl.checkAuthTrans(paramStream,2,application);
        		if(AuthTrans == 0){
    				ajaxPrintPage(response, "0");
					return;
    			}else{
    				ajaxPrintPage(response, "1");
    			}
			} catch (Exception e) {
				// TODO: handle exception
				LogUtils.info("-------AuthTrans exception--------");
				ajaxPrintPage(response, "1");
			}
			commonAddPTi(paramStream,"2",request,application);	//鉴权成功  增加播放次数
        }
    }

    /**
     * 点播鉴权
     * 
     * @param paramStream
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/auth/videoup_play")
    public void authVOD(@ModelAttribute("paramStream") ParamStream paramStream,HttpServletRequest request,
            HttpServletResponse response) {
    	application = request.getServletContext();
    	LogUtils.info("--videoup auth--rid"+paramStream.getChannel());
    	int slog = 0;
		slog = ocRdisSLog(slog,application);
		if(slog == 1){
	    	LogUtils.info("---------点播播放鉴全参数end--------");
		}
    	String ip = request.getHeader("cdn-src-ip");
    	if(StringUtils.isBlank(ip)){
    		ip = request.getHeader("x-forwarded-for");
    	}
        if (paramStream == null || StringUtils.isEmpty(paramStream.getToken()) || StringUtils.isEmpty(paramStream.getChannel())) {
        	LogUtils.info("---videoup_play param error---");
        	ajaxPrintPage(response, "0");
        	return ;
        }
        String md5Val = MD5Utils.getMD5String(paramStream.getChannel()+"bk");
		if(StringUtils.isNotBlank(paramStream.getSourceType()) && StringUtils.isNotEmpty(paramStream.getSourceType())){
			if(md5Val.equals(paramStream.getSourceType()) || md5Val == paramStream.getSourceType()){
				//直通
				ajaxPrintPage(response, "1");
				return;
			}else{
				LogUtils.info("点播鉴全直通签名不匹配，md5Val:"+md5Val+";sourceType:"+paramStream.getSourceType());
			}
		}
        paramStream.setClientip(ip);
        paramStream.setPlaySource("3");
		int resInt = liveStreamServiceImpl.authVOD(paramStream,application);
        if (resInt == 0) {
        	//LogUtils.info("点播 鉴权失败 0 ：" + paramStream.getChannel());
        	ajaxPrintPage(response, "0");
        	//ajaxPrintPage(response, "1");
        	return ;
        } else {
        	//如果配置了鉴权转移功能 则将鉴权移交配置的三方回调处理
        	int AuthTrans = 1;
        	try {
        		AuthTrans = liveStreamServiceImpl.checkAuthTrans(paramStream,3,application);
    			if(AuthTrans == 0){
    				ajaxPrintPage(response, "0");
					return;
    			}else{
    				ajaxPrintPage(response, "1");
    			}
			} catch (Exception e) {
				// TODO: handle exception
				LogUtils.info("-------AuthTrans exception--------");
				ajaxPrintPage(response, "1");
			}
			commonAddPTi(paramStream,"3",request,application);	//鉴权成功  增加播放次数
        }
    }
    
    /**
     * NVR 2018 点播鉴权
     * 
     * @param paramStream
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/auth/vnp")
    public void authVnp(@ModelAttribute("paramStream") ParamStream paramStream,HttpServletRequest request,
            HttpServletResponse response) {
    	application = request.getServletContext();
    	LogUtils.info("--nvr videoup auth--rid"+paramStream.getChannel());
    	int slog = 0;
		slog = ocRdisSLog(slog,application);
		if(slog == 1){
	    	LogUtils.info("---------nvr点播播放鉴全参数end--------");
		}
    	String ip = request.getHeader("cdn-src-ip");
    	if(StringUtils.isBlank(ip)){
    		ip = request.getHeader("x-forwarded-for");
    	}
        if (paramStream == null || StringUtils.isEmpty(paramStream.getToken()) || StringUtils.isEmpty(paramStream.getChannel())) {
        	LogUtils.info("---videoup_play param error---");
        	ajaxPrintPage(response, "0");
        	return ;
        }
        String md5Val = MD5Utils.getMD5String(paramStream.getChannel()+"bk");
		if(StringUtils.isNotBlank(paramStream.getSourceType())){
			if(md5Val.equals(paramStream.getSourceType()) || md5Val == paramStream.getSourceType()){
				//直通
				ajaxPrintPage(response, "1");
				return;
			}else{
				LogUtils.info("点播鉴全直通签名不匹配，md5Val:"+md5Val+";sourceType:"+paramStream.getSourceType());
			}
		}
        paramStream.setClientip(ip);
        paramStream.setPlaySource("3");
		int resInt = liveStreamServiceImpl.authVOD(paramStream,application);
        if (resInt == 0) {
        	ajaxPrintPage(response, "0");
        	return ;
        } else {
        	//如果配置了鉴权转移功能 则将鉴权移交配置的三方回调处理
        	int AuthTrans = 1;
        	try {
        		AuthTrans = liveStreamServiceImpl.checkAuthTrans(paramStream,3,application);
    			if(AuthTrans == 0){
    				ajaxPrintPage(response, "0");
					return;
    			}else{
    				ajaxPrintPage(response, "1");
    			}
			} catch (Exception e) {
				// TODO: handle exception
				LogUtils.info("-------AuthTrans exception--------");
				ajaxPrintPage(response, "1");
			}
			commonAddPTi(paramStream,"3",request,application);	//鉴权成功  增加播放次数
        }
    }
    
	
	/**
	 * 推流鉴权
	 * @param paramStream
	 * @return  1:成功  0：失败
	 */
	//@ResponseBody
	@RequestMapping(value="/auth/publish")
	public void authPublish(@ModelAttribute("paramStream") ParamStream paramStream,HttpServletRequest request,
            HttpServletResponse response){
		application = request.getServletContext();
		int res = commonParamDisposePu(paramStream);
		if(res == 0){
			LogUtils.info("---play param error---");
			ajaxPrintPage(response, "0");
        	return ;
		}
		//判断必要参数
		LogUtils.info("--live_push auth--rid:"+paramStream.getChannel());
		int slog = 0;
		slog = ocRdisSLog(slog,application);
		if(slog == 1){
	    	LogUtils.info("---------直播推流鉴全参数end--------");
		}
		if (paramStream==null || StringUtils.isBlank(paramStream.getToken()) || StringUtils.isBlank(paramStream.getChannel()) ||  StringUtils.isBlank(paramStream.getSecret()) || StringUtils.isBlank(paramStream.getPush_code())){
			LogUtils.info("---push param error---");
			ajaxPrintPage(response, "0");
        	return ;
		}
		//业务相同 调用播放鉴权
		int resInt = liveStreamServiceImpl.authPublish(paramStream,application);
		if (resInt==0){
			LogUtils.info("推流   鉴权失败 0 ："+paramStream.getChannel());
			ajaxPrintPage(response, "0");
        	return ;				
		}else{
			//LogUtils.info("推流   鉴权成功 1 ："+paramStream.getChannel());
			ajaxPrintPage(response, "1");
        	return ;
		}
	}
	
	
	/**
	 * 回调接口设置限制人数
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/auth/liveLimitCount") 
	public ResultCode liveLimitCount(
			@RequestParam(value="yunLiveId",required=false) String liveId,
			@RequestParam(value="limitCount",required=false) Integer limitCount,
			HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin","*");//设置跨域允许
		response.setContentType("application/xml;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		if(StringUtils.isBlank(liveId) || null == limitCount){
			LogUtils.info("---liveLimitCount param error---");
			return ResultCodeDataStr.ERROR("invalid argument");
		}
		int res = liveStreamServiceImpl.liveLimitCount(liveId, limitCount);
		if(res == 1){
			return  ResultCodeDataStr.ERROR();
    	}else{
    		 return  ResultCodeDataStr.SUCCESS();
    	}
	}
	
	/**
	 * 回调接口设置某个用户的限制人数  -1 无限制   -2 使用默认  -3错误  正整数 正常限制
	 * 对于三方预警同步使用此规则，-1 不预警  -2 默认预警机制   正整数：限定时间内首次达到设定鉴全次数时 向三方告警
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/auth/liveLimitUserCount") 
	public ResultCode liveLimitUserCount(
			@RequestParam(value="userid",required=false) String userid,
			@RequestParam(value="limitCount",required=false) Integer limitCount,
			HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin","*");//设置跨域允许
		response.setContentType("application/xml;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		if(StringUtils.isBlank(userid) || null == limitCount){
			LogUtils.info("---liveLimitCount param error---");
			return ResultCodeDataStr.ERROR("invalid argument");
		}
		if(limitCount < -3){
			LogUtils.info("---liveLimitCount param error---");
			return ResultCodeDataStr.ERROR("invalid argument");
		}
		int res = liveStreamServiceImpl.liveLimitUserCount(userid, limitCount);
		if(res == -3){
			return  ResultCodeDataStr.ERROR();
    	}else{
    		return  ResultCodeDataStr.INFO("200", "SUCCESS", res+"");	
    	}
	}
	
	//三方鉴权回调
	public int authThirdCommon(ParamStream paramStream,int type,ServletContext application){
		int AuthTrans = liveStreamServiceImpl.checkAuthTrans(paramStream,type,application);
		return AuthTrans;
	}
	
	//大用户按token增加播放次数  集成公共鉴全计数器  保持3分钟 用于估算在线人数情况
	public void commonAddPTi(ParamStream paramStream,String type,HttpServletRequest request,ServletContext application){
		liveStreamServiceImpl.commonAddPTi(paramStream, type,request,application);
	}
	
	/**
	 * @author WQS
	 * @time 2018-1-24 10:12:22
	 * type  0禁止  1开启
	 * liveID 直播id
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/auth/streamswitch")
	public ResultCode streamswitch(@RequestParam(value="liveID",required=false) String liveID,
			@RequestParam(value="type",required=false) String type,
			HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin","*");//设置跨域允许
		response.setContentType("application/xml;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		if(StringUtils.isBlank(liveID) || null == type){
			LogUtils.info("---liveLimitCount param error---");
			return ResultCodeDataStr.ERROR("invalid argument");
		}
		int resInt = liveStreamServiceImpl.streamswitch(liveID,type);
		if(resInt == 1){
			return  ResultCodeDataStr.SUCCESS();	
    	}else{
    		 return  ResultCodeDataStr.ERROR();
    	}
	}
	
	/**
	 * @author WQS
	 * @time 2018-1-24 10:12:22
	 * liveID 直播id  查看鉴全开关
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/auth/get_streamswitch")
	public ResultCode get_streamswitch(@RequestParam(value="liveID",required=false) String liveID,
			HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin","*");//设置跨域允许
		response.setContentType("application/xml;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		if(StringUtils.isBlank(liveID)){
			LogUtils.info("---liveLimitCount param error---");
			return ResultCodeDataStr.ERROR("invalid argument");
		}
		int resInt = liveStreamServiceImpl.streamswitch(liveID,"3");
		if(resInt == 0){
			return  ResultCodeDataStr.INFO("200", "返回成功", "当前直播鉴全开关：禁止播放");	
    	}else if(resInt == 1){
    		return  ResultCodeDataStr.INFO("200", "返回成功", "当前直播鉴全开关：允许播放");	
    	}else{
    		return  ResultCodeDataStr.INFO("200", "返回成功", "当前直播鉴全开关：未设置或者已失效");	
    	}
	}
	
	/**
	 * @author WQS
	 * @time 2018-1-24 10:12:22
	 * liveID 直播id  删除鉴全开关
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/auth/del_streamswitch")
	public ResultCode del_streamswitch(@RequestParam(value="liveID",required=false) String liveID,
			HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin","*");//设置跨域允许
		response.setContentType("application/xml;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		if(StringUtils.isBlank(liveID)){
			LogUtils.info("---liveLimitCount param error---");
			return ResultCodeDataStr.ERROR("invalid argument");
		}
		int resInt = liveStreamServiceImpl.streamswitch(liveID,"4");
		if(resInt == 1){
			return  ResultCodeDataStr.INFO("200", "成功", "当前直播鉴全开关：已经删除");	
    	}else if(resInt == 0){
    		return  ResultCodeDataStr.INFO("400", "失败", "当前直播鉴全开关：未删除");	
    	}else{
    		return  ResultCodeDataStr.INFO("500", "操作异常", "服务器内部错误");	
    	}
	}
	
	/**
	 * @author WQS
	 * @time 2018-1-24 10:12:22
	 * 测试使用
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/auth/test") 
	public ResultCodeDataStr streamTest(
			HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin","*");//设置跨域允许
		response.setContentType("application/xml;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		return  ResultCodeDataStr.SUCCESS();
	}
	
	/**
	 * @author WQS
	 * @time 2018-1-24 10:12:22
	 * 测试使用
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/auth/test1") 
	public void streamTest1(
			@ModelAttribute("paramStream") ParamStream paramStream,HttpServletResponse response,ServletContext application){
		response.setHeader("Access-Control-Allow-Origin","*");//设置跨域允许
		response.setContentType("application/xml;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		if (paramStream==null || StringUtils.isBlank(paramStream.getToken()) || StringUtils.isBlank(paramStream.getChannel()) ||  StringUtils.isBlank(paramStream.getSecret())){
			ajaxPrintPage(response, "0");
        	return ;
		}
		int resInt = liveStreamServiceImpl.authTest(paramStream,1,application);
		if(resInt == 1){
			ajaxPrintPage(response, "1");
			return;
		}
		ajaxPrintPage(response, "0");
    	return ;
	}
	
	/**
	 * @author WQS
	 * @time 2018-1-24 10:12:22
	 * 测试使用
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/auth/test2") 
	public void streamTest2(
			@ModelAttribute("paramStream") ParamStream paramStream,HttpServletResponse response,ServletContext application){
		response.setHeader("Access-Control-Allow-Origin","*");//设置跨域允许
		response.setContentType("application/xml;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		if (paramStream==null || StringUtils.isBlank(paramStream.getToken()) || StringUtils.isBlank(paramStream.getChannel()) ||  StringUtils.isBlank(paramStream.getSecret())){
			ajaxPrintPage(response, "0");
        	return ;
		}
		int resInt = liveStreamServiceImpl.authTest(paramStream,2,application);
		if(resInt == 1){
			ajaxPrintPage(response, "1");
			return;
		}
		ajaxPrintPage(response, "0");
    	return ;
	}
	
	/**
	 * @author WQS
	 * @time 2018-1-24 10:12:22
	 * 测试使用
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/auth/test3") 
	public void streamTest3(
			@ModelAttribute("paramStream") ParamStream paramStream,HttpServletResponse response,ServletContext application){
		response.setHeader("Access-Control-Allow-Origin","*");//设置跨域允许
		response.setContentType("application/xml;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		if (paramStream==null || StringUtils.isBlank(paramStream.getToken()) || StringUtils.isBlank(paramStream.getChannel()) ||  StringUtils.isBlank(paramStream.getSecret())){
			ajaxPrintPage(response, "0");
        	return ;
		}
		int resInt = liveStreamServiceImpl.authTest(paramStream,3,application);
		if(resInt == 1){
			ajaxPrintPage(response, "1");
			return;
		}
		ajaxPrintPage(response, "0");
    	return ;
	}
	
	/**
	 * 做一些鉴权操作
	 */
	@ModelAttribute
	private void init(HttpServletRequest request,HttpServletResponse response){
		
	}
	
	public void ajaxPrintPage(HttpServletResponse response,Object obj) {
		response.setCharacterEncoding("UTF-8");
		PrintWriter writer = null;
			try {
				//writer = response.getWriter();
				writer = new PrintWriter(new OutputStreamWriter(response.getOutputStream(),"UTF-8"));
				if (null == obj)
					writer.print(obj);
				else
					writer.print(obj.toString());
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
}
