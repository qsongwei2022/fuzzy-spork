//
//************************************公共函数部分************************************
//获得系统当前时间
function getTime(){
	var oDate = new Date(); //实例一个时间对象；
	var yyyy = oDate.getFullYear();   //获取系统的年；
	var MM = oDate.getMonth()+1;   //获取系统月份，由于月份是从0开始计算，所以要加1
	var dd = oDate.getDate(); // 获取系统日，
	var HH = oDate.getHours(); //获取系统时，
	var mm = oDate.getMinutes(); //分
	var ss = oDate.getSeconds(); //秒
	

	
	if (MM<10){
		MM="0"+MM;
	}
	if (dd<10){
		dd="0"+dd;
	}
	if (HH<10){
		HH="0"+HH;
	}
	if (mm<10){
		mm="0"+mm;
	}
	if (ss<10){
		ss="0"+ss;
	}
	return yyyy+""+MM+""+dd+""+HH+""+mm+""+ss;
}

$("#create_time").val(getTime());

$(document).ready(function(){
    $("#userid").keyup(function(){
    	var value = $("#userid").val();
    	$("#ap_token").val(value);
    	$("#apu_token").val(value);
    });
});

//************************************播放鉴权************************************
$("#ap_token").val("22fd832373133c8d64ff");

function onsubmint_ap(){
	var aps = $("#ap_secret").val();
	var apsi = $("#ap_channel").val();
	if (apsi==''){
		alert("请输入channel");
		$("#ap_channel").focus();
		return false;
	}	
	if (aps==''){
		alert("请输入secret");
		$("#ap_secret").focus();
		return false;
	}
	return true;
}

function getAPMd5(){

	//$("#ap_create_time").val(  $("#create_time").val() );
	//$("#ap_expires").val( $("#expires").val() );
	var token = $("#userid").val();
	var gpsi = $("#ap_channel").val();
	var ct = $("#ap_create_time").val();
	var ex = $("#ap_expires").val();
	ct = ""; ex = "";
	var user_key = $("#user_key").val();
	var md5value="";
	if(ct=='' || ex==''){
		md5value=token+"#"+gpsi+"#"+user_key;
	}else{
		md5value=token+"#"+gpsi+"#"+ct+"#"+ex+"#"+user_key;
	}
	md5value = hex_md5(md5value);
	$("#ap_secret").val(md5value);
}

//************************************推流鉴权************************************
$("#apu_token").val("22fd832373133c8d64ff");

function onsubmint_apu(){
	var apus = $("#apu_secret").val();
	var apusi = $("#apu_channel").val();
	if (apusi==''){
		alert("请输入stream_id");
		$("#apu_channel").focus();
		return false;
	}	
	if (apus==''){
		alert("请输入secret");
		$("#apu_secret").focus();
		return false;
	}
	return true;
}

function getAPUMd5(){
	$("#apu_create_time").val(  $("#create_time").val() );
	$("#apu_expires").val( $("#expires").val() );	
	var token = $("#userid").val();
	var gpsi = $("#apu_channel").val();
	var ct = $("#apu_create_time").val();
	var ex = $("#apu_expires").val();
	ct = ""; ex = "";
	var user_key = $("#user_key").val();
	var md5value="";
	if(ct=='' || ex==''){
		md5value=token+"#"+gpsi+"#"+user_key;
	}else{
		md5value=token+"#"+gpsi+"#"+ct+"#"+ex+"#"+user_key;
	}
	md5value = hex_md5(md5value);
	$("#apu_secret").val(md5value);
}